import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import { HabeshaEngine, RUNNERS } from "./game/engine";
import { AudioEngine } from "./game/audio";
import {
  loadScores, submitScore, loadSettings, saveSettings, loadRunner, saveRunner, pad,
  type ScoreEntry, type Settings, type RunResult,
} from "./game/storage";

type Screen = "menu" | "playing" | "paused" | "over" | "runners" | "leaders" | "options" | "exit";

/* ----------------------------- icons ----------------------------- */
const I = {
  play: <path d="M8 5v14l11-7z" />,
  pause: <path d="M6 5h4v14H6zM14 5h4v14h-4z" />,
  trophy: <path d="M7 4V2h10v2h4v4c0 2.2-1.8 4-4 4h-.5A6 6 0 0 1 13 15.9V18h3v2H8v-2h3v-2.1A6 6 0 0 1 7.5 12H7c-2.2 0-4-1.8-4-4V4h4zm0 2H5v2c0 1.1.9 2 2 2V6zm10 0v4c1.1 0 2-.9 2-2V6h-2z" />,
  gear: <path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm9 4a7 7 0 0 0-.1-1.2l2-1.5-2-3.5-2.4 1a7 7 0 0 0-2-1.2L16 3h-4l-.4 2.6a7 7 0 0 0-2 1.2l-2.5-1-2 3.5 2 1.5A7 7 0 0 0 7 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.5 2.4-1c.6.5 1.3.9 2 1.2L12 21h4l.4-2.6c.7-.3 1.4-.7 2-1.2l2.4 1 2-3.5-2-1.5c.1-.4.2-.8.2-1.2z" />,
  users: <path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0 2c-3.3 0-8 1.7-8 5v3h16v-3c0-3.3-4.7-5-8-5zm8-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3zm-1.5 6.2A5.6 5.6 0 0 1 21 19v3h3v-3c0-2.4-2.6-4-5.5-4.8z" />,
  door: <path d="M13 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8v-2H5V5h8v14h2l4-4v-6l-4-4V3zm3 10V9l3 3-3 3v-2H8v-2h8z" />,
  left: <path d="M15 4l-8 8 8 8 2-2-6-6 6-6z" />,
  right: <path d="M9 4l8 8-8 8-2-2 6-6-6-6z" />,
  home: <path d="M12 3l9 8h-3v9h-5v-6h-2v6H6v-9H3z" />,
  redo: <path d="M12 5V2L7 7l5 5V8a6 6 0 1 1-6 6H4a8 8 0 1 0 8-9z" />,
  bean: <path d="M12 2C7 2 3 6.5 3 12s4 10 9 10 9-4.5 9-10S17 2 12 2zm0 3c1 2 1 4 0 7s-1 5 0 7c-3.3 0-6-3.1-6-7s2.7-7 6-7z" />,
  sound: <path d="M4 9v6h4l6 5V4L8 9H4zm12.5 3a3.5 3.5 0 0 0-2-3.2v6.4a3.5 3.5 0 0 0 2-3.2zM14.5 4v2.1a6 6 0 0 1 0 11.8V20a8 8 0 0 0 0-16z" />,
  music: <path d="M12 3v10.6A4 4 0 1 0 14 17V7h6V3h-8z" />,
  x: <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" fill="none" />,
};

function Icon({ d, className = "w-5 h-5" }: { d: keyof typeof I; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      {I[d]}
    </svg>
  );
}

/* ------------------------- small components ---------------------- */
function MenuButton({ icon, label, amh, onClick, primary }: { icon: keyof typeof I; label: string; amh?: string; onClick: () => void; primary?: boolean }) {
  return (
    <button onClick={onClick} className="group flex w-full items-center justify-end gap-3 py-2.5 min-h-[52px] text-right">
      <span className="flex flex-col items-end leading-none">
        <span className={`font-display text-2xl sm:text-3xl tracking-wide hr-text-shadow transition-all group-hover:translate-x-1 ${primary ? "text-sun-400" : "text-cream-50"}`}>
          {label}
        </span>
        {amh && <span className="font-amh text-[11px] text-cream-300/70 mt-1">{amh}</span>}
      </span>
      <span className={`grid place-items-center w-9 h-9 rounded-full hr-chip text-cream-100 transition-transform group-hover:scale-110 ${primary ? "hr-glow" : ""}`}>
        <Icon d={icon} />
      </span>
    </button>
  );
}

function Slider({ label, value, onChange, icon }: { label: string; value: number; onChange: (v: number) => void; icon: keyof typeof I }) {
  const pct = Math.round(value * 100);
  return (
    <div className="hr-chip rounded-xl px-4 py-3">
      <div className="flex items-center gap-3 font-bold text-cream-50 mb-2">
        <Icon d={icon} className="w-5 h-5 text-sun-400" /> {label}
        <span className="ml-auto text-xs text-cream-300/70 font-extrabold">{pct}%</span>
      </div>
      <input
        type="range" min={0} max={100} value={pct}
        onChange={(e) => onChange(Number(e.target.value) / 100)}
        className="hr-range" style={{ "--fill": `${pct}%` } as CSSProperties}
        aria-label={label}
      />
    </div>
  );
}

function Toggle({ on, onClick, label, icon }: { on: boolean; onClick: () => void; label: string; icon: keyof typeof I }) {
  return (
    <button onClick={onClick} className="flex items-center justify-between w-full px-4 py-3 rounded-xl hr-chip text-cream-50">
      <span className="flex items-center gap-3 font-bold">
        <Icon d={icon} className="w-5 h-5 text-sun-400" /> {label}
      </span>
      <span className={`relative w-12 h-6 rounded-full transition-colors ${on ? "bg-leaf-500" : "bg-bark-600"}`}>
        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-cream-50 shadow transition-all ${on ? "left-6" : "left-0.5"}`} />
      </span>
    </button>
  );
}

function ScoreTable({ scores, compact }: { scores: ScoreEntry[]; compact?: boolean }) {
  const rows = compact ? scores.slice(0, 3) : scores.slice(0, 6);
  return (
    <div className="w-full">
      <div className="flex justify-between px-4 pb-2 text-cream-300/80 font-extrabold text-xs tracking-widest uppercase">
        <span>Runner</span><span>Scores</span>
      </div>
      <div className="space-y-1.5">
        {rows.map((s, i) => (
          <div key={i} className={`flex items-center justify-between px-4 py-2 rounded-xl ${s.you ? "bg-sun-500/25 border border-sun-400/50" : "bg-bark-950/40"}`}>
            <span className="flex items-center gap-2 font-bold text-cream-50">
              <span className="text-sun-400 w-4">{i + 1}.</span>
              {s.name}
              {s.you && <span className="text-[10px] text-sun-400 font-extrabold uppercase">(High Score)</span>}
            </span>
            <span className="flex items-baseline gap-2">
              {typeof s.beans === "number" && (
                <span className="flex items-center gap-0.5 text-[10px] text-cream-300/70 font-bold">
                  <Icon d="bean" className="w-3 h-3 text-sun-400" />{s.beans}
                </span>
              )}
              <span className="font-display text-lg text-cream-50">{s.score}</span>
              <span className="text-xs text-cream-300/70 font-bold">{s.dist}m</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================== APP =============================== */
export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<HabeshaEngine | null>(null);
  const audioRef = useRef<AudioEngine | null>(null);
  const scoreRef = useRef<HTMLSpanElement>(null);
  const distRef = useRef<HTMLSpanElement>(null);
  const beanRef = useRef<HTMLSpanElement>(null);
  const gemRef = useRef<HTMLSpanElement>(null);
  const toastTimer = useRef<number>(0);

  const [screen, setScreen] = useState<Screen>("menu");
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [settings, setSettings] = useState<Settings>(() => loadSettings());
  const [runnerIdx, setRunnerIdx] = useState<number>(() => loadRunner());
  const [result, setResult] = useState<(RunResult & { score: number; dist: number; beans: number; gems: number }) | null>(null);
  const [hint, setHint] = useState(true);
  const [toast, setToast] = useState<string | null>(null);

  /* boot engine once */
  useEffect(() => {
    if (!mountRef.current) return;
    const audio = new AudioEngine();
    audioRef.current = audio;
    const engine = new HabeshaEngine(mountRef.current, audio, {
      onHud: (score, dist, beans, gems) => {
        if (scoreRef.current) scoreRef.current.textContent = pad(score, 4);
        if (distRef.current) distRef.current.textContent = pad(dist, 4) + "m";
        const bump = (el: HTMLSpanElement | null, val: string) => {
          if (!el || el.textContent === val) return;
          el.textContent = val;
          el.classList.remove("hr-bump");
          void el.offsetWidth;
          el.classList.add("hr-bump");
        };
        bump(beanRef.current, String(beans));
        bump(gemRef.current, String(gems));
      },
      onToast: (msg) => {
        setToast(msg);
        window.clearTimeout(toastTimer.current);
        toastTimer.current = window.setTimeout(() => setToast(null), 1800);
      },
      onGameOver: (r) => {
        const res = submitScore(r.score, r.dist, r.beans);
        setResult({ ...res, ...r });
        setScores(res.scores);
        if (res.isNewBest) audio.newHigh();
        setScreen("over");
      },
      onState: (s) => {
        if (s === "paused") setScreen("paused");
        else if (s === "running") setScreen("playing");
        else if (s === "menu") setScreen("menu");
      },
    });
    engineRef.current = engine;
    engine.setRunner(loadRunner());
    engine.applyQuality(loadSettings().quality);
    return () => { engine.dispose(); audio.dispose(); };
  }, []);

  /* apply settings */
  useEffect(() => {
    saveSettings(settings);
    const a = audioRef.current;
    if (a) {
      a.setSfx(settings.sfx);
      a.setMusic(settings.music);
      a.setSfxVol(settings.sfxVol);
      a.setMusicVol(settings.musicVol);
    }
    engineRef.current?.applyQuality(settings.quality);
  }, [settings]);

  const click = useCallback((fn: () => void) => {
    audioRef.current?.unlock();
    audioRef.current?.click();
    fn();
  }, []);

  const startGame = () => click(() => { engineRef.current?.startRun(); setScreen("playing"); setHint(true); window.setTimeout(() => setHint(false), 3500); });
  const toMenu = () => click(() => { engineRef.current?.toMenu(); setScreen("menu"); });

  const changeRunner = (dir: number) => click(() => {
    setRunnerIdx((prev) => {
      const next = (prev + dir + RUNNERS.length) % RUNNERS.length;
      saveRunner(next);
      engineRef.current?.setRunner(next);
      return next;
    });
  });

  const runner = RUNNERS[runnerIdx];
  const inGame = screen === "playing" || screen === "paused";

  return (
    <div className="relative w-full h-full overflow-hidden bg-bark-950 font-body">
      {/* 3D canvas */}
      <div ref={mountRef} className="absolute inset-0" />

      {/* vignette + warm grade */}
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 90% at 50% 40%, transparent 55%, rgba(40,18,4,0.42) 100%)" }} />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-24" style={{ background: "linear-gradient(180deg, rgba(40,18,4,0.35), transparent)" }} />

      {/* ============ HUD ============ */}
      {inGame && (
        <div className="absolute inset-0 pointer-events-none hr-fade pt-[env(safe-area-inset-top)] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)]">
          <div className="absolute top-3 left-3 hr-chip rounded-2xl px-4 py-2">
            <div className="text-[10px] font-extrabold tracking-[0.2em] text-cream-300/80 uppercase">Score</div>
            <div className="font-display text-2xl text-cream-50 leading-none"><span ref={scoreRef}>0000</span></div>
          </div>
          <div className="absolute top-3 right-3 flex items-start gap-2">
            <div className="hr-chip rounded-2xl px-4 py-2 text-right">
              <div className="text-[10px] font-extrabold tracking-[0.2em] text-cream-300/80 uppercase">Distance</div>
              <div className="font-display text-2xl text-cream-50 leading-none"><span ref={distRef}>0000m</span></div>
            </div>
            <button
              onClick={() => click(() => engineRef.current?.pause())}
              className="pointer-events-auto hr-chip rounded-2xl w-12 h-12 grid place-items-center text-cream-100 active:scale-90 transition-transform"
              aria-label="Pause"
            >
              <Icon d="pause" className="w-5 h-5" />
            </button>
          </div>
          {/* collectibles + best */}
          <div className="absolute top-20 left-3 flex flex-col gap-1.5 items-start">
            <div className="hr-chip rounded-full px-3 py-1.5 flex items-center gap-2">
              <Icon d="bean" className="w-4 h-4 text-sun-400" />
              <span className="font-display text-lg text-cream-50 leading-none"><span ref={beanRef}>0</span></span>
            </div>
            <div className="hr-chip rounded-full px-3 py-1.5 flex items-center gap-2">
              <svg viewBox="0 0 24 24" className="w-4 h-4 text-yellow-300" fill="currentColor" aria-hidden>
                <circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5.5" fill="#b87400" />
                <path d="M12 8.5v7M8.5 12h7" stroke="#ffe9a8" strokeWidth="1.6" />
              </svg>
              <span className="font-display text-lg text-cream-50 leading-none"><span ref={gemRef}>0</span></span>
            </div>
            <div className="hr-chip rounded-full px-3 py-1 text-[10px] font-extrabold tracking-widest text-cream-300/80 uppercase">
              Best {scores[0]?.score ?? 0}
            </div>
          </div>
          {/* reward toast */}
          {toast && (
            <div className="absolute top-24 inset-x-0 flex justify-center pointer-events-none">
              <div className="hr-pop hr-gold-card px-5 py-2 font-display text-lg text-bark-950 tracking-wide" style={{ textShadow: "0 1px 0 rgba(255,255,255,0.4)" }}>
                {toast}
              </div>
            </div>
          )}
          {/* mini leaders */}
          <div className="absolute bottom-3 right-3 hidden sm:block hr-chip rounded-2xl px-3 py-2 w-40">
            <div className="text-[9px] font-extrabold tracking-[0.18em] text-cream-300/80 uppercase pb-1">High Scores</div>
            {scores.slice(0, 3).map((s, i) => (
              <div key={i} className="flex justify-between text-[11px] font-bold text-cream-100/90 leading-5">
                <span>{i + 1}. {s.name}</span><span>{s.score}</span>
              </div>
            ))}
          </div>
          {/* touch / key hint */}
          {hint && screen === "playing" && (
            <div className="absolute bottom-24 sm:bottom-6 inset-x-0 flex justify-center hr-fade">
              <div className="hr-chip rounded-full px-5 py-2 text-cream-100 text-sm font-bold flex items-center gap-3">
                <span className="hidden sm:inline">← → move · ↑ jump · ↓ slide</span>
                <span className="sm:hidden">{settings.touchButtons ? "Use the buttons or swipe" : "Swipe to move · up to jump · down to slide"}</span>
              </div>
            </div>
          )}
          {/* on-screen touch controls */}
          {settings.touchButtons && screen === "playing" && (
            <div className="absolute inset-x-0 bottom-0 pb-5 px-5 flex justify-between items-end pointer-events-none hr-fade">
              <div className="flex gap-3 pointer-events-auto">
                <button
                  aria-label="Move left"
                  onPointerDown={(e) => { e.preventDefault(); engineRef.current?.moveLane(-1); }}
                  className="w-16 h-16 rounded-full hr-chip text-cream-100 grid place-items-center active:scale-90 active:bg-sun-500/30 transition"
                >
                  <Icon d="left" className="w-7 h-7" />
                </button>
                <button
                  aria-label="Move right"
                  onPointerDown={(e) => { e.preventDefault(); engineRef.current?.moveLane(1); }}
                  className="w-16 h-16 rounded-full hr-chip text-cream-100 grid place-items-center active:scale-90 active:bg-sun-500/30 transition"
                >
                  <Icon d="right" className="w-7 h-7" />
                </button>
              </div>
              <div className="flex gap-3 pointer-events-auto">
                <button
                  aria-label="Slide"
                  onPointerDown={(e) => { e.preventDefault(); engineRef.current?.doSlide(); }}
                  className="w-16 h-16 rounded-full hr-chip text-cream-100 grid place-items-center active:scale-90 active:bg-sun-500/30 transition"
                >
                  <svg viewBox="0 0 24 24" className="w-7 h-7" fill="currentColor"><path d="M12 16l-6-6h12z" /></svg>
                </button>
                <button
                  aria-label="Jump"
                  onPointerDown={(e) => { e.preventDefault(); engineRef.current?.doJump(); }}
                  className="w-16 h-16 rounded-full hr-btn hr-btn-fire grid place-items-center"
                >
                  <svg viewBox="0 0 24 24" className="w-7 h-7" fill="currentColor"><path d="M12 8l6 6H6z" /></svg>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============ MAIN MENU ============ */}
      {screen === "menu" && (
        <div className="absolute inset-0 hr-fade pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)]">
          <div className="pointer-events-none absolute inset-y-0 right-0 w-3/5" style={{ background: "linear-gradient(270deg, rgba(28,15,5,0.6) 0%, rgba(28,15,5,0.24) 55%, transparent 100%)" }} />
          <div className="absolute top-5 left-5 sm:top-10 sm:left-10">
            <div className="hr-float">
              <h1 className="font-display text-4xl min-[420px]:text-5xl sm:text-7xl text-cream-50 hr-text-shadow leading-[0.95]">
                HABESHA<br /><span className="text-sun-400">RUNNER</span>
              </h1>
              <p className="font-amh text-cream-100/80 mt-2 text-sm sm:text-base">የሐበሻ ሯጭ · ቡና ሀገር</p>
            </div>
          </div>
          <div className="absolute right-4 sm:right-14 top-1/2 -translate-y-1/2 w-56 min-[420px]:w-64 sm:w-72 max-h-[86vh] overflow-y-auto hr-stagger">
            <div className="text-right mb-3">
              <div className="font-display text-xl text-cream-300/90 tracking-wide">MAIN MENU</div>
              <div className="font-amh text-xs text-cream-300/60">ዋና ምናሌ</div>
            </div>
            <div className="flex flex-col gap-1">
            <MenuButton primary icon="play" label="PLAY" amh="ጫወት" onClick={startGame} />
            <MenuButton icon="users" label="RUNNERS" amh="ሯጮች" onClick={() => click(() => setScreen("runners"))} />
            <MenuButton icon="trophy" label="LEADERBOARD" amh="መሪዎች" onClick={() => click(() => setScreen("leaders"))} />
            <MenuButton icon="gear" label="OPTIONS" amh="አማራጮች" onClick={() => click(() => setScreen("options"))} />
            <MenuButton icon="door" label="EXIT" amh="ውጣ" onClick={() => click(() => setScreen("exit"))} />
            </div>
          </div>
          <div className="absolute bottom-3 inset-x-0 text-center text-cream-100/55 text-[11px] sm:text-xs font-bold tracking-wide px-4">
            Best: {scores[0]?.score ?? 0} pts · Run through the highlands at golden hour
          </div>
        </div>
      )}

      {/* ============ RUNNER SELECT ============ */}
      {screen === "runners" && (
        <div className="absolute inset-0 bg-bark-950/55 hr-fade">
          <div className="absolute inset-y-0 left-0 w-1/2" style={{ background: "radial-gradient(60% 50% at 50% 55%, rgba(255,214,130,0.22), transparent 70%)" }} />
          <button onClick={() => changeRunner(-1)} className="absolute left-3 sm:left-10 top-1/2 -translate-y-1/2 text-cream-100 hover:text-sun-400 active:scale-90 transition" aria-label="Previous runner">
            <Icon d="left" className="w-10 h-10 sm:w-14 sm:h-14" />
          </button>
          <button onClick={() => changeRunner(1)} className="absolute right-3 sm:right-[42%] top-1/2 -translate-y-1/2 text-cream-100 hover:text-sun-400 active:scale-90 transition" aria-label="Next runner">
            <Icon d="right" className="w-10 h-10 sm:w-14 sm:h-14" />
          </button>
          <div className="absolute right-4 sm:right-10 top-1/2 -translate-y-1/2 w-64 hr-panel rounded-3xl p-5 hr-pop">
            <div className="flex items-center gap-2">
              <div className="font-display text-2xl text-sun-400 hr-text-shadow">{runner.name}</div>
              <span className="text-[9px] font-extrabold uppercase tracking-widest bg-leaf-500/25 text-green-300 border border-green-400/40 rounded-full px-2 py-0.5">Unlocked</span>
            </div>
            <div className="font-amh text-xs text-cream-300/70 mb-2">{runner.place}</div>
            <div className="space-y-1.5 mb-3">
              {(["Speed", "Agility", "Luck"] as const).map((lbl, i) => (
                <div key={lbl} className="flex items-center gap-2">
                  <span className="w-14 text-[10px] font-extrabold uppercase tracking-wider text-cream-300/70">{lbl}</span>
                  <div className="flex-1 h-2 rounded-full bg-bark-950/60 overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-500" style={{ width: `${runner.stats[i] * 20}%`, background: "linear-gradient(90deg,#ff9d2e,#ffd24a)" }} />
                  </div>
                </div>
              ))}
            </div>
            <div className="h-px bg-cream-300/15 my-3" />
            <div className="text-[10px] font-extrabold tracking-[0.2em] text-cream-300/80 uppercase mb-2">Equipment</div>
            {runner.gear.map((g) => (
              <div key={g} className="flex items-center gap-3 bg-bark-950/50 rounded-xl px-3 py-2.5 mb-2">
                <span className="w-9 h-9 rounded-lg bg-sun-500/20 grid place-items-center text-sun-400"><Icon d="bean" /></span>
                <span className="font-extrabold text-cream-50 text-sm leading-tight">{g}</span>
              </div>
            ))}
            <button onClick={() => click(() => setScreen("menu"))} className="hr-btn hr-btn-wood w-full py-2.5 mt-2 text-lg">BACK</button>
          </div>
          <div className="absolute top-5 left-5">
            <div className="font-display text-3xl text-cream-50 hr-text-shadow">CHOOSE YOUR RUNNER</div>
            <div className="font-amh text-sm text-cream-300/70">ሯጭህን ምረጥ</div>
          </div>
        </div>
      )}

      {/* ============ LEADERBOARD ============ */}
      {screen === "leaders" && (
        <div className="absolute inset-0 bg-bark-950/60 hr-fade grid place-items-center p-4">
          <div className="hr-panel rounded-3xl p-6 w-full max-w-md hr-pop">
            <div className="text-center mb-4">
              <div className="font-display text-3xl text-sun-400 hr-text-shadow">ETHIOPIAN RUNNER LEADERS</div>
              <div className="font-amh text-sm text-cream-300/70 mt-1">የኢትዮጵያ ሯች መሪዎች</div>
            </div>
            <ScoreTable scores={scores} />
            <button onClick={() => click(() => setScreen("menu"))} className="hr-btn hr-btn-wood w-full py-3 mt-5 text-xl">BACK</button>
          </div>
        </div>
      )}

      {/* ============ OPTIONS ============ */}
      {screen === "options" && (
        <div className="absolute inset-0 bg-bark-950/60 hr-fade grid place-items-center p-4">
          <div className="hr-panel rounded-3xl p-6 w-full max-w-sm hr-pop space-y-3">
            <div className="text-center mb-1">
              <div className="font-display text-3xl text-sun-400 hr-text-shadow">OPTIONS</div>
              <div className="font-amh text-sm text-cream-300/70">አማራጮች</div>
            </div>
            <Toggle on={settings.sfx} icon="sound" label="Sound Effects" onClick={() => click(() => setSettings((s) => ({ ...s, sfx: !s.sfx })))} />
            <Toggle on={settings.music} icon="music" label="Music" onClick={() => click(() => setSettings((s) => ({ ...s, music: !s.music })))} />
            <Slider label="Music Volume" icon="music" value={settings.musicVol} onChange={(v) => setSettings((s) => ({ ...s, musicVol: v }))} />
            <Slider label="Effects Volume" icon="sound" value={settings.sfxVol} onChange={(v) => setSettings((s) => ({ ...s, sfxVol: v }))} />
            <Toggle on={settings.touchButtons} icon="gear" label="Touch Buttons" onClick={() => click(() => setSettings((s) => ({ ...s, touchButtons: !s.touchButtons })))} />
            <div className="hr-chip rounded-xl px-4 py-3">
              <div className="font-bold text-cream-50 mb-2">Graphics Quality</div>
              <div className="grid grid-cols-3 gap-2">
                {(["low", "medium", "high"] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => click(() => setSettings((s) => ({ ...s, quality: q })))}
                    className={`py-2 rounded-lg font-extrabold text-sm capitalize transition ${settings.quality === q ? "bg-sun-500 text-bark-950" : "bg-bark-950/50 text-cream-300"}`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={() => click(() => { localStorage.removeItem("habesha-runner-scores-v1"); setScores(loadScores()); })}
              className="w-full py-2.5 rounded-xl font-extrabold text-sm text-cream-300 bg-bark-950/50 hover:bg-ember-600/40 transition"
            >
              Reset High Scores
            </button>
            <button onClick={() => click(() => setScreen("menu"))} className="hr-btn hr-btn-wood w-full py-3 text-xl">BACK</button>
          </div>
        </div>
      )}

      {/* ============ PAUSE ============ */}
      {screen === "paused" && (
        <div className="absolute inset-0 bg-bark-950/60 backdrop-blur-md hr-fade grid place-items-center p-4 pt-[env(safe-area-inset-top)]">
          <div className="hr-panel rounded-3xl p-5 w-full max-w-xs hr-pop space-y-2.5 text-center max-h-[92vh] overflow-y-auto">
            <div className="font-display text-4xl text-cream-50 hr-text-shadow">PAUSED</div>
            <div className="font-amh text-sm text-cream-300/70 -mt-1">ጨታው ቆሟል</div>
            <button onClick={() => click(() => engineRef.current?.resume())} className="hr-btn hr-btn-fire w-full py-3 text-xl">RESUME</button>
            <button onClick={startGame} className="hr-btn hr-btn-wood w-full py-2.5 text-lg flex items-center justify-center gap-2"><Icon d="redo" className="w-4 h-4" /> RESTART</button>
            <div className="text-left space-y-2">
              <Slider label="Music Volume" icon="music" value={settings.musicVol} onChange={(v) => setSettings((s) => ({ ...s, musicVol: v }))} />
              <Slider label="Effects Volume" icon="sound" value={settings.sfxVol} onChange={(v) => setSettings((s) => ({ ...s, sfxVol: v }))} />
            </div>
            <button onClick={toMenu} className="hr-btn hr-btn-stone w-full py-2.5 text-lg flex items-center justify-center gap-2"><Icon d="home" className="w-4 h-4" /> MAIN MENU</button>
          </div>
        </div>
      )}

      {/* ============ GAME OVER ============ */}
      {screen === "over" && result && (
        <div className="absolute inset-0 bg-bark-950/45 hr-fade grid place-items-center p-4">
          <div className="hr-gold-card w-full max-w-sm p-2 hr-pop">
            <div className="rounded-[22px] bg-bark-900/90 px-5 py-5">
              <div className="text-center">
                <div className="font-display text-5xl text-cream-50 hr-text-shadow">GAME OVER</div>
                {result.isNewBest ? (
                  <div className="hr-shine font-display text-xl text-sun-400 mt-1 rounded">NEW HIGH SCORE!</div>
                ) : (
                  <div className="font-amh text-sm text-cream-300/70 mt-1">ጨዋታው አልቋል</div>
                )}
              </div>
              <div className="grid grid-cols-4 gap-1.5 my-4 text-center hr-stagger">
                <div className="bg-bark-950/60 rounded-xl py-2">
                  <div className="text-[8px] font-extrabold tracking-widest text-cream-300/70 uppercase">Score</div>
                  <div className="font-display text-xl text-sun-400">{result.score}</div>
                </div>
                <div className="bg-bark-950/60 rounded-xl py-2">
                  <div className="text-[8px] font-extrabold tracking-widest text-cream-300/70 uppercase">Dist</div>
                  <div className="font-display text-xl text-cream-50">{result.dist}m</div>
                </div>
                <div className="bg-bark-950/60 rounded-xl py-2">
                  <div className="text-[8px] font-extrabold tracking-widest text-cream-300/70 uppercase">Beans</div>
                  <div className="font-display text-xl text-cream-50">{result.beans}</div>
                </div>
                <div className="bg-bark-950/60 rounded-xl py-2">
                  <div className="text-[8px] font-extrabold tracking-widest text-cream-300/70 uppercase">Coins</div>
                  <div className="font-display text-xl text-yellow-300">{result.gems}</div>
                </div>
              </div>
              <div className="text-center -mt-2 mb-3 text-xs font-extrabold tracking-widest text-cream-300/70 uppercase">
                Best Score: <span className="text-sun-400 font-display text-sm">{scores[0]?.score ?? result.score}</span>
              </div>
              <ScoreTable scores={result.scores} compact />
              <button onClick={startGame} className="hr-btn hr-btn-fire w-full py-3.5 text-2xl mt-5 hr-glow">RUN AGAIN</button>
              <button onClick={toMenu} className="hr-btn hr-btn-stone w-full py-2.5 text-lg mt-2">MAIN MENU</button>
            </div>
          </div>
        </div>
      )}

      {/* ============ EXIT ============ */}
      {screen === "exit" && (
        <div className="absolute inset-0 bg-bark-950/70 hr-fade grid place-items-center p-4">
          <div className="hr-panel rounded-3xl p-7 w-full max-w-xs hr-pop text-center">
            <div className="font-display text-3xl text-cream-50 hr-text-shadow">SELAM!</div>
            <p className="text-cream-300/80 font-bold mt-2 text-sm">Thanks for running the highlands. Your beans are safe — come back soon.</p>
            <div className="font-amh text-cream-300/60 text-sm mt-2">እናመሰግናለን</div>
            <button onClick={() => click(() => setScreen("menu"))} className="hr-btn hr-btn-fire w-full py-3 text-xl mt-5">BACK TO MENU</button>
          </div>
        </div>
      )}
    </div>
  );
}
