/* Local persistence: high-score table, settings, selected runner. */

export interface ScoreEntry {
  name: string;
  score: number;
  dist: number;
  beans?: number;
  you?: boolean;
}

export interface Settings {
  sfx: boolean;
  music: boolean;
  quality: "high" | "medium" | "low";
  touchButtons: boolean;
  musicVol: number;
  sfxVol: number;
}

const SCORES_KEY = "habesha-runner-scores-v1";
const SETTINGS_KEY = "habesha-runner-settings-v1";
const RUNNER_KEY = "habesha-runner-runner-v1";

const SEED: ScoreEntry[] = [
  { name: "Meseret D.", score: 145, dist: 28, beans: 22 },
  { name: "Haile G.", score: 130, dist: 25, beans: 18 },
  { name: "Kenenisa B.", score: 112, dist: 21, beans: 15 },
  { name: "Tirunesh A.", score: 96, dist: 18, beans: 12 },
];

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(SCORES_KEY);
    if (!raw) return [...SEED];
    const parsed = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(parsed) || parsed.length === 0) return [...SEED];
    return parsed;
  } catch {
    return [...SEED];
  }
}

export interface RunResult {
  rank: number;
  isNewBest: boolean;
  scores: ScoreEntry[];
}

export function submitScore(score: number, dist: number, beans = 0): RunResult {
  const scores = loadScores();
  const prevBest = scores.reduce((m, s) => (s.you ? Math.max(m, s.score) : m), 0);
  // Keep a single personal-best entry — no duplicate "You" rows.
  for (let i = scores.length - 1; i >= 0; i--) if (scores[i].you) scores.splice(i, 1);
  scores.push({ name: "You", score, dist, beans, you: true });
  scores.sort((a, b) => b.score - a.score);
  const trimmed = scores.slice(0, 10);
  try {
    localStorage.setItem(SCORES_KEY, JSON.stringify(trimmed));
  } catch {
    /* storage full / private mode — ignore */
  }
  const rank = trimmed.findIndex((s) => s.you && s.score === score);
  return { rank, isNewBest: score > prevBest && score > 0, scores: trimmed };
}

export function loadSettings(): Settings {
  const coarse = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { sfx: true, music: true, quality: coarse ? "medium" : "high", touchButtons: !!coarse, musicVol: 0.7, sfxVol: 0.9, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { sfx: true, music: true, quality: coarse ? "medium" : "high", touchButtons: !!coarse, musicVol: 0.7, sfxVol: 0.9 };
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

export function loadRunner(): number {
  try {
    const v = parseInt(localStorage.getItem(RUNNER_KEY) ?? "0", 10);
    return Number.isFinite(v) ? Math.max(0, Math.min(2, v)) : 0;
  } catch {
    return 0;
  }
}

export function saveRunner(i: number) {
  try {
    localStorage.setItem(RUNNER_KEY, String(i));
  } catch {
    /* ignore */
  }
}

export const pad = (n: number, w: number) => Math.max(0, Math.floor(n)).toString().padStart(w, "0");
