import * as THREE from "three";
import type { AudioEngine } from "./audio";

/* ------------------------------------------------------------------ */
/*  Runner variants                                                    */
/* ------------------------------------------------------------------ */
export interface RunnerVariant {
  name: string;
  place: string;
  shirt: number;
  sleeves: number;
  shorts: number;
  skin: number;
  shoe: number;
  gear: [string, string];
  stats: [number, number, number]; // speed / agility / luck
}

export const RUNNERS: RunnerVariant[] = [
  { name: "Baro", place: "Jimma Highlands", shirt: 0xf1ede2, sleeves: 0x8b95a7, shorts: 0x3d5a80, skin: 0x7a4a2b, shoe: 0x6e4a2f, gear: ["Coffee Bean Boots", "Tilet Sash"], stats: [4, 4, 3] },
  { name: "Simien", place: "Simien Mountains", shirt: 0x2f7d3b, sleeves: 0x265f2e, shorts: 0x2c2c34, skin: 0x6e4126, shoe: 0x3a2a1c, gear: ["Trail Sandals", "Gabi Wrap"], stats: [3, 5, 3] },
  { name: "Awash", place: "Awash Valley", shirt: 0xc8502e, sleeves: 0x9c3d22, shorts: 0x463222, skin: 0x84512f, shoe: 0x54381f, gear: ["Marathon Flats", "Netela Band"], stats: [5, 3, 4] },
];

export const LANES = [-2.2, 0, 2.2];
const CHUNK_LEN = 60;
const CHUNK_COUNT = 6;
const SPAWN_Z = -185;

export type EngineState = "menu" | "running" | "paused" | "over";
export type Quality = "high" | "medium" | "low";

export interface EngineCallbacks {
  onHud: (score: number, dist: number, beans: number, gems: number) => void;
  onGameOver: (r: { score: number; dist: number; beans: number; gems: number }) => void;
  onState: (s: EngineState) => void;
  onToast: (msg: string) => void;
}

/* ------------------------------------------------------------------ */
/*  Canvas texture helpers                                             */
/* ------------------------------------------------------------------ */
function canvasTex(size: number, draw: (c: CanvasRenderingContext2D, s: number) => void): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = cv.height = size;
  const c = cv.getContext("2d")!;
  draw(c, size);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 2;
  return t;
}

const texTilet = () =>
  canvasTex(128, (c, s) => {
    c.fillStyle = "#e8dcc4";
    c.fillRect(0, 0, s, s);
    const bands = ["#d43d2a", "#f2b32a", "#2f7d3b", "#d43d2a", "#1f5c8f"];
    for (let i = 0; i < 5; i++) {
      c.fillStyle = bands[i];
      c.fillRect(0, (s / 5) * i, s, s / 5);
      c.fillStyle = "rgba(255,255,255,0.5)";
      for (let x = 4; x < s; x += 12) c.fillRect(x, (s / 5) * i + 3, 5, 3);
      c.fillStyle = "rgba(0,0,0,0.25)";
      for (let x = 10; x < s; x += 12) c.fillRect(x, (s / 5) * i + s / 5 - 6, 5, 3);
    }
  });

const texFlag = () =>
  canvasTex(64, (c, s) => {
    c.fillStyle = "#2f9e44"; c.fillRect(0, 0, s, s / 3);
    c.fillStyle = "#f5c518"; c.fillRect(0, s / 3, s, s / 3);
    c.fillStyle = "#d43d2a"; c.fillRect(0, (s / 3) * 2, s, s / 3);
  });

const texThatch = () =>
  canvasTex(128, (c, s) => {
    c.fillStyle = "#b98d4f";
    c.fillRect(0, 0, s, s);
    for (let i = 0; i < 220; i++) {
      c.strokeStyle = `rgba(${90 + Math.random() * 60},${60 + Math.random() * 40},25,0.5)`;
      const x = Math.random() * s;
      c.beginPath(); c.moveTo(x, Math.random() * s); c.lineTo(x + 2, Math.random() * s); c.stroke();
    }
    c.fillStyle = "rgba(60,35,12,0.35)";
    for (let y = 16; y < s; y += 22) c.fillRect(0, y, s, 3);
  });

const texMud = () =>
  canvasTex(128, (c, s) => {
    c.clearRect(0, 0, s, s);
    for (let i = 0; i < 7; i++) {
      c.fillStyle = `rgba(${70 + Math.random() * 30},${44 + Math.random() * 18},22,${0.55 + Math.random() * 0.3})`;
      c.beginPath();
      c.ellipse(Math.random() * s, Math.random() * s, 14 + Math.random() * 26, 8 + Math.random() * 16, Math.random() * 3, 0, Math.PI * 2);
      c.fill();
    }
  });

const texBush = () =>
  canvasTex(128, (c, s) => {
    c.fillStyle = "#3f7d2a";
    c.fillRect(0, 0, s, s);
    for (let i = 0; i < 90; i++) {
      c.fillStyle = Math.random() > 0.5 ? "#2f6320" : "#57993a";
      c.beginPath(); c.arc(Math.random() * s, Math.random() * s, 4 + Math.random() * 7, 0, Math.PI * 2); c.fill();
    }
    for (let i = 0; i < 26; i++) {
      c.fillStyle = Math.random() > 0.3 ? "#c9302c" : "#e05545";
      c.beginPath(); c.arc(Math.random() * s, Math.random() * s, 2.5 + Math.random() * 2, 0, Math.PI * 2); c.fill();
      c.fillStyle = "rgba(255,255,255,0.7)";
      c.fillRect(Math.random() * s, Math.random() * s, 1.5, 1.5);
    }
  });

const texFlowers = () =>
  canvasTex(128, (c, s) => {
    c.fillStyle = "#4c8a2e";
    c.fillRect(0, 0, s, s);
    for (let i = 0; i < 70; i++) {
      c.fillStyle = Math.random() > 0.5 ? "#3c7224" : "#5f9c36";
      c.beginPath(); c.arc(Math.random() * s, Math.random() * s, 4 + Math.random() * 6, 0, Math.PI * 2); c.fill();
    }
    for (let i = 0; i < 22; i++) {
      const x = Math.random() * s, y = Math.random() * s;
      c.fillStyle = "#ffd23e";
      for (let p = 0; p < 6; p++) {
        const a = (p / 6) * Math.PI * 2;
        c.beginPath(); c.arc(x + Math.cos(a) * 3, y + Math.sin(a) * 3, 2, 0, Math.PI * 2); c.fill();
      }
      c.fillStyle = "#f07f1a";
      c.beginPath(); c.arc(x, y, 1.8, 0, Math.PI * 2); c.fill();
    }
  });

const texCloud = () =>
  canvasTex(128, (c, s) => {
    c.clearRect(0, 0, s, s);
    for (let i = 0; i < 6; i++) {
      const g = c.createRadialGradient(s / 2 + (Math.random() - 0.5) * 50, s / 2 + (Math.random() - 0.5) * 18, 2, s / 2, s / 2, 40 + Math.random() * 20);
      g.addColorStop(0, "rgba(255,240,220,0.8)");
      g.addColorStop(1, "rgba(255,240,220,0)");
      c.fillStyle = g;
      c.fillRect(0, 0, s, s);
    }
  });

const texSoft = () =>
  canvasTex(64, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.5, "rgba(255,255,255,0.5)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    c.fillStyle = g;
    c.fillRect(0, 0, s, s);
  });

const texShadow = () =>
  canvasTex(64, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 2, s / 2, s / 2, s / 2);
    g.addColorStop(0, "rgba(30,15,5,0.55)");
    g.addColorStop(1, "rgba(30,15,5,0)");
    c.fillStyle = g;
    c.fillRect(0, 0, s, s);
  });

const texGlow = () =>
  canvasTex(256, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, "rgba(255,244,200,0.95)");
    g.addColorStop(0.25, "rgba(255,200,110,0.55)");
    g.addColorStop(1, "rgba(255,170,70,0)");
    c.fillStyle = g;
    c.fillRect(0, 0, s, s);
  });

const texWater = () =>
  canvasTex(128, (c, s) => {
    c.fillStyle = "#3f8fb8";
    c.fillRect(0, 0, s, s);
    for (let i = 0; i < 40; i++) {
      c.strokeStyle = `rgba(200,235,255,${0.15 + Math.random() * 0.2})`;
      c.lineWidth = 2;
      const y = Math.random() * s;
      c.beginPath(); c.moveTo(0, y); c.bezierCurveTo(s * 0.3, y - 4, s * 0.6, y + 4, s, y); c.stroke();
    }
  });

/* ------------------------------------------------------------------ */
/*  Particle system (Points based)                                     */
/* ------------------------------------------------------------------ */
class Particles {
  points: THREE.Points;
  private pos: Float32Array;
  private vel: Float32Array;
  private life: Float32Array;
  private max: number;
  private cursor = 0;
  private gravity: number;

  constructor(max: number, size: number, color: number, gravity: number, map: THREE.Texture, blending: THREE.Blending) {
    this.max = max;
    this.gravity = gravity;
    this.pos = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    const m = new THREE.PointsMaterial({
      size, map, transparent: true, depthWrite: false, color, blending, sizeAttenuation: true, opacity: 0.95,
    });
    this.points = new THREE.Points(geo, m);
    this.points.frustumCulled = false;
    for (let i = 0; i < max; i++) { this.pos[i * 3 + 1] = -999; }
  }

  burst(x: number, y: number, z: number, count: number, speed: number, up = 0.5) {
    for (let n = 0; n < count; n++) {
      const i = this.cursor;
      this.cursor = (this.cursor + 1) % this.max;
      this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
      const a = Math.random() * Math.PI * 2;
      const r = (0.3 + Math.random() * 0.7) * speed;
      this.vel[i * 3] = Math.cos(a) * r;
      this.vel[i * 3 + 1] = (Math.random() * 0.8 + up) * speed;
      this.vel[i * 3 + 2] = Math.sin(a) * r;
      this.life[i] = 0.5 + Math.random() * 0.5;
    }
  }

  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      this.vel[i * 3 + 1] -= this.gravity * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      if (this.life[i] <= 0) this.pos[i * 3 + 1] = -999;
    }
    (this.points.geometry.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
  }
}

/* ------------------------------------------------------------------ */
/*  The engine                                                         */
/* ------------------------------------------------------------------ */
interface Obstacle {
  group: THREE.Group;
  type: "low" | "high" | "block" | "goat";
  lane: number;
  active: boolean;
  goatHead?: THREE.Object3D;
  wheelL?: THREE.Object3D;
  wheelR?: THREE.Object3D;
}

interface Chunk {
  group: THREE.Group;
  decor: THREE.Object3D[];
}

export class HabeshaEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private audio: AudioEngine;
  private cb: EngineCallbacks;
  private clock = new THREE.Clock();
  private raf = 0;
  private disposed = false;

  state: EngineState = "menu";
  private quality: Quality = "high";

  /* player */
  private player!: THREE.Group;
  private pRoot!: THREE.Group;
  private pBody!: THREE.Group;
  private pHipL!: THREE.Group; private pHipR!: THREE.Group;
  private pKneeL!: THREE.Group; private pKneeR!: THREE.Group;
  private pShL!: THREE.Group; private pShR!: THREE.Group;
  private pElbL!: THREE.Group; private pElbR!: THREE.Group;
  private pShadow!: THREE.Mesh;

  private lane = 1;
  private px = 0;
  private py = 0;
  private vy = 0;
  private sliding = 0;
  private jumpQueued = false;

  /* world */
  private speed = 0;
  private distance = 0;
  private beans = 0;
  private combo = 0;
  private comboTimer = 0;
  private chunks: Chunk[] = [];
  private obstacles: Obstacle[] = [];
  private nextSpawn = 0;
  private coins!: THREE.InstancedMesh;
  private coinData: { x: number; y: number; z: number; active: boolean; ph: number }[] = [];
  private coinCursor = 0;
  private gems!: THREE.InstancedMesh;
  private gemData: { x: number; y: number; z: number; active: boolean; ph: number }[] = [];
  private gemsCollected = 0;
  private bonus = 0;
  private lastMilestone = 0;
  private dust!: Particles;
  private spark!: Particles;
  private rings: { m: THREE.Mesh; t: number }[] = [];
  private clouds: THREE.Sprite[] = [];
  private birds: { g: THREE.Group; wL: THREE.Mesh; wR: THREE.Mesh; ph: number }[] = [];
  private shake = 0;
  private crashT = 0;
  private time = 0;
  private camX = 0;
  private waterTex = texWater();
  private sunGlow!: THREE.Sprite;
  private density = 1;
  /* animation blend state */
  private airBlend = 0;
  private slideBlend = 0;
  private squash = 0;
  private themeCursor = 0;
  private lastStepSign = 1;
  private stepAlt = false;

  private dummy = new THREE.Object3D();

  constructor(container: HTMLElement, audio: AudioEngine, cb: EngineCallbacks) {
    this.container = container;
    this.audio = audio;
    this.cb = cb;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    container.appendChild(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(62, container.clientWidth / container.clientHeight, 0.1, 500);
    this.camera.position.set(-3.2, 2, 3.8);

    this.scene.fog = new THREE.Fog(0xf0a45c, 45, 165);

    this.buildSky();
    this.buildLights();
    this.buildBackdrop();
    this.buildGround();
    this.buildChunks();
    this.buildPlayer(RUNNERS[0]);
    this.pRoot.rotation.y = Math.PI; // face the menu camera
    this.buildPools();

    this.bindInput();
    this.applyQuality(this.quality);
    this.loop();
  }

  /* ------------------------- environment ------------------------- */
  private buildSky() {
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(320, 24, 16),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: {
          top: { value: new THREE.Color(0xffb45c) },
          mid: { value: new THREE.Color(0xffd98e) },
          bot: { value: new THREE.Color(0xffe9b8) },
        },
        vertexShader: `varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `varying vec3 vP; uniform vec3 top; uniform vec3 mid; uniform vec3 bot;
          void main(){ float h = normalize(vP).y;
            vec3 col = h > 0.12 ? mix(mid, top, smoothstep(0.12, 0.6, h)) : mix(bot, mid, smoothstep(-0.05, 0.12, h));
            gl_FragColor = vec4(col, 1.0); }`,
      })
    );
    this.scene.add(sky);

    const sun = new THREE.Mesh(new THREE.SphereGeometry(16, 24, 24), new THREE.MeshBasicMaterial({ color: 0xfff4cf, fog: false }));
    sun.position.set(36, 34, -290);
    this.scene.add(sun);

    this.sunGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: texGlow(), transparent: true, depthWrite: false, fog: false, opacity: 0.9 }));
    this.sunGlow.scale.set(150, 150, 1);
    this.sunGlow.position.copy(sun.position);
    this.scene.add(this.sunGlow);
  }

  private buildLights() {
    this.scene.add(new THREE.HemisphereLight(0xffd9a6, 0x7a5530, 1.05));
    const sun = new THREE.DirectionalLight(0xffc384, 2.0);
    sun.position.set(20, 30, -40);
    this.scene.add(sun);
    const fill = new THREE.DirectionalLight(0xffe6c0, 0.5);
    fill.position.set(-15, 12, 20);
    this.scene.add(fill);
  }

  private mat(color: number, emissive = 0x000000) {
    return new THREE.MeshLambertMaterial({ color, emissive });
  }

  private matCache = new Map<string, THREE.MeshLambertMaterial>();
  private matCached(color: number | THREE.Color) {
    const key = typeof color === "number" ? color.toString(16) : "c" + color.getHexString();
    let m = this.matCache.get(key);
    if (!m) {
      m = new THREE.MeshLambertMaterial({ color });
      this.matCache.set(key, m);
    }
    return m;
  }

  private buildBackdrop() {
    const far = new THREE.Group();
    const mFar = this.mat(0xb06a3a);
    const mNear = this.mat(0x8a5a4a);
    for (let i = 0; i < 11; i++) {
      const h = 26 + Math.random() * 34;
      const m = new THREE.Mesh(new THREE.ConeGeometry(24 + Math.random() * 20, h, 5), i % 2 ? mFar : mNear);
      m.position.set(-120 + i * 24 + Math.random() * 10, h / 2 - 4, -250 - Math.random() * 30);
      m.rotation.y = Math.random() * Math.PI;
      far.add(m);
    }
    // rolling green hills mid-distance
    const mHill = this.mat(0x6f9f3a);
    for (let i = 0; i < 9; i++) {
      const h = 10 + Math.random() * 12;
      const m = new THREE.Mesh(new THREE.SphereGeometry(18 + Math.random() * 14, 10, 8), mHill);
      m.scale.y = h / 20;
      m.position.set(-110 + i * 28, h * 0.35 - 3, -150 - Math.random() * 40);
      far.add(m);
    }
    this.scene.add(far);
  }

  private buildGround() {
    const g = new THREE.Mesh(new THREE.PlaneGeometry(500, 600), this.mat(0x79a83e));
    g.rotation.x = -Math.PI / 2;
    g.position.set(0, -0.05, -200);
    this.scene.add(g);
  }

  /* --------------------------- props ----------------------------- */
  private shadowTex = texShadow();

  private bushTex = texBush();
  private makeBush(): THREE.Group {
    const g = new THREE.Group();
    const b1 = new THREE.Mesh(this.geoBushA, this.bushMat);
    b1.position.y = 0.75; b1.scale.set(1, 0.9, 1);
    g.add(b1);
    const b2 = new THREE.Mesh(this.geoBushB, this.bushMat);
    b2.position.set(0.5, 1.15, 0.2);
    g.add(b2);
    return g;
  }

  private makeAcacia(): THREE.Group {
    const g = new THREE.Group();
    const trunk = new THREE.Mesh(this.geoTrunk, this.matCached(0x6e4a28));
    trunk.position.y = 1.1;
    g.add(trunk);
    const leaf = new THREE.Mesh(this.geoLeafA, this.matCached(0x4e8a2c));
    leaf.position.y = 2.6; leaf.scale.set(1.4, 0.6, 1.4);
    g.add(leaf);
    const leaf2 = new THREE.Mesh(this.geoLeafB, this.matCached(0x5f9c36));
    leaf2.position.set(0.8, 2.3, 0.3); leaf2.scale.set(1.2, 0.55, 1.2);
    g.add(leaf2);
    return g;
  }

  private thatchTex = texThatch();
  private makeTukul(scale = 1): THREE.Group {
    const g = new THREE.Group();
    const wall = new THREE.Mesh(this.geoTukulWall, this.matCached(0xc9a06a));
    wall.position.y = 0.85;
    g.add(wall);
    const roof = new THREE.Mesh(this.geoTukulRoof, this.thatchMat);
    roof.position.y = 2.55;
    g.add(roof);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 1.1), this.matCached(0x2a1608));
    door.position.set(0, 0.62, 1.58);
    g.add(door);
    g.scale.setScalar(scale);
    return g;
  }

  private makeTerrace(): THREE.Group {
    const g = new THREE.Group();
    const cols = [0x7fae45, 0x6f9f3a, 0x86b84c, 0x658f33];
    for (let i = 0; i < 4; i++) {
      const w = 10 - i * 2.1;
      const b = new THREE.Mesh(new THREE.BoxGeometry(w, 1, w * 0.8), this.mat(cols[i]));
      b.position.y = 0.5 + i;
      g.add(b);
    }
    return g;
  }

  private makeJebena(): THREE.Group {
    const g = new THREE.Group();
    const m = this.mat(0x241410);
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.28, 10, 8), m);
    body.position.y = 0.28; body.scale.y = 1.15;
    g.add(body);
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.12, 0.3, 8), m);
    neck.position.y = 0.62;
    g.add(neck);
    return g;
  }

  private makeEnset(): THREE.Group {
    // enset / false banana — iconic Ethiopian crop
    const g = new THREE.Group();
    const trunk = new THREE.Mesh(this.geoEnsetTrunk, this.matCached(0x7aa04a));
    trunk.position.y = 0.7;
    g.add(trunk);
    const leafM = this.matCached(0x3f8a2c);
    const leafM2 = this.matCached(0x57a23a);
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2;
      const leaf = new THREE.Mesh(this.geoEnsetLeaf, i % 2 ? leafM2 : leafM);
      leaf.position.set(Math.cos(a) * 0.55, 1.6 + (i % 3) * 0.12, Math.sin(a) * 0.55);
      leaf.rotation.y = -a;
      leaf.rotation.x = 0.55;
      g.add(leaf);
    }
    return g;
  }

  private makeCoffeeRow(): THREE.Group {
    // neat farm row of coffee bushes with support posts
    const g = new THREE.Group();
    const postM = this.matCached(0x6e4a28);
    for (let i = 0; i < 4; i++) {
      const b = new THREE.Mesh(this.geoCoffee, this.bushMat);
      b.position.set(0, 0.55, i * 1.7 - 2.5);
      b.scale.set(1, 0.85, 1);
      g.add(b);
      if (i % 2 === 0) {
        const p = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.9, 5), postM);
        p.position.set(0.55, 0.45, i * 1.7 - 2.5);
        g.add(p);
      }
    }
    return g;
  }

  private makeFence(): THREE.Group {
    const g = new THREE.Group();
    const wood = this.mat(0x7a5530);
    for (let i = 0; i < 4; i++) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.8, 5), wood);
      p.position.set(0, 0.4, i * 1.1 - 1.65);
      g.add(p);
    }
    for (const y of [0.55, 0.3]) {
      const r = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 3.6, 5), wood);
      r.rotation.x = Math.PI / 2;
      r.position.y = y;
      g.add(r);
    }
    return g;
  }

  private flowerTex = texFlowers();
  private makeFlowers(): THREE.Group {
    const g = new THREE.Group();
    const b = new THREE.Mesh(this.geoFlower, this.flowerMat);
    b.position.y = 0.4; b.scale.set(1.5, 0.5, 1.2);
    g.add(b);
    return g;
  }

  private makeOutcrop(): THREE.Group {
    const g = new THREE.Group();
    const m = this.mat(0x8d8578);
    for (let i = 0; i < 4; i++) {
      const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.5 + Math.random() * 0.9, 0), m);
      r.position.set((Math.random() - 0.5) * 2.4, r.geometry.parameters.radius * 0.6, (Math.random() - 0.5) * 2);
      r.rotation.set(Math.random(), Math.random(), Math.random());
      g.add(r);
    }
    return g;
  }

  private makeCampfire(): THREE.Group {
    const g = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      const log = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.9, 5), this.mat(0x5a3a1e));
      log.rotation.z = Math.PI / 2;
      log.rotation.y = (i / 5) * Math.PI;
      log.position.y = 0.1;
      g.add(log);
    }
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.7, 8), new THREE.MeshBasicMaterial({ color: 0xffa12e }));
    flame.position.y = 0.45;
    flame.name = "flame";
    g.add(flame);
    const glow = new THREE.PointLight(0xff8a2a, 6, 8);
    glow.position.y = 0.7;
    g.add(glow);
    return g;
  }

  private makeGoat(): THREE.Group {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.42, 0.95), this.mat(0xe8e2d4));
    body.position.y = 0.62;
    g.add(body);
    const head = new THREE.Group();
    const hm = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.3, 0.38), this.mat(0xe8e2d4));
    head.add(hm);
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.22, 5), this.mat(0x8a7a5a));
    horn.position.set(0.06, 0.22, 0.05); horn.rotation.z = -0.4;
    head.add(horn);
    const horn2 = horn.clone(); horn2.position.x = -0.06; horn2.rotation.z = 0.4;
    head.add(horn2);
    head.position.set(0, 0.85, 0.55);
    g.add(head);
    const legM = this.mat(0xd8d2c4);
    [[-0.16, 0.34], [0.16, 0.34], [-0.16, -0.34], [0.16, -0.34]].forEach(([x, z]) => {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.04, 0.45, 5), legM);
      leg.position.set(x, 0.22, z);
      g.add(leg);
    });
    g.userData.head = head;
    return g;
  }

  private makeCart(): THREE.Group {
    const g = new THREE.Group();
    const wood = this.mat(0x7a4f28);
    const bed = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.5, 2.6), wood);
    bed.position.y = 0.75;
    g.add(bed);
    const rail = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.14, 2.7), this.mat(0x5f3c1d));
    rail.position.y = 1.05;
    g.add(rail);
    const wheelGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.12, 12);
    const wheelM = this.mat(0x4a2f16);
    const wl = new THREE.Mesh(wheelGeo, wheelM); wl.rotation.z = Math.PI / 2; wl.position.set(-0.9, 0.55, 0.6);
    const wr = wl.clone(); wr.position.x = 0.9;
    const wl2 = wl.clone(); wl2.position.z = -0.7;
    const wr2 = wr.clone(); wr2.position.z = -0.7;
    g.add(wl, wr, wl2, wr2);
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 1.6), wood);
    handle.position.set(0, 0.7, 2.0); handle.rotation.x = 0.25;
    g.add(handle);
    // hay load
    const hay = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7, 1), this.mat(0xd8b04a));
    hay.position.set(0, 1.25, -0.3); hay.scale.set(1.1, 0.7, 1.5);
    g.add(hay);
    return g;
  }

  private makeRock(): THREE.Group {
    const g = new THREE.Group();
    const m = this.mat(0x8d8578);
    const m2 = this.mat(0x756e62);
    const r1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.8, 0), m);
    r1.position.y = 0.6; r1.scale.set(1.1, 0.9, 1);
    g.add(r1);
    const r2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.5, 0), m2);
    r2.position.set(0.55, 0.35, 0.3);
    g.add(r2);
    const r3 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.42, 0), m2);
    r3.position.set(-0.5, 0.3, -0.25);
    g.add(r3);
    return g;
  }

  private makeLog(): THREE.Group {
    const g = new THREE.Group();
    const m = this.mat(0x6e4a28);
    const log = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 2.0, 8), m);
    log.rotation.z = Math.PI / 2;
    log.position.y = 0.34;
    g.add(log);
    const postM = this.mat(0x54381f);
    const p1 = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 0.6, 6), postM);
    p1.position.set(-0.85, 0.3, 0);
    const p2 = p1.clone(); p2.position.x = 0.85;
    g.add(p1, p2);
    return g;
  }

  private makeBranch(): THREE.Group {
    const g = new THREE.Group();
    const postM = this.mat(0x5f3c1d);
    const p1 = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 2.1, 6), postM);
    p1.position.set(-1.05, 1.05, 0);
    const p2 = p1.clone(); p2.position.x = 1.05;
    g.add(p1, p2);
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 2.4, 6), postM);
    beam.rotation.z = Math.PI / 2;
    beam.position.y = 1.75;
    g.add(beam);
    const leafM = this.mat(0x4e8a2c);
    for (let i = 0; i < 5; i++) {
      const l = new THREE.Mesh(new THREE.IcosahedronGeometry(0.28, 0), leafM);
      l.position.set(-0.9 + i * 0.45, 1.62 - (i % 2) * 0.12, 0.1);
      g.add(l);
    }
    return g;
  }

  /* ------------------------- world chunks ------------------------ */
  private mudTex = texMud();

  /* shared caches — chunk recycling must stay allocation-light */
  private bushMat = new THREE.MeshLambertMaterial({ map: this.bushTex });
  private flowerMat = new THREE.MeshLambertMaterial({ map: this.flowerTex });
  private mudMat = new THREE.MeshLambertMaterial({ map: this.mudTex, transparent: true });
  private waterMat = new THREE.MeshLambertMaterial({ map: this.waterTex, transparent: true, opacity: 0.95 });
  private thatchMat = new THREE.MeshLambertMaterial({ map: this.thatchTex });
  private geoBushA = new THREE.IcosahedronGeometry(0.85, 1);
  private geoBushB = new THREE.IcosahedronGeometry(0.55, 1);
  private geoCoffee = new THREE.IcosahedronGeometry(0.62, 1);
  private geoFlower = new THREE.IcosahedronGeometry(0.7, 1);
  private geoLeafA = new THREE.IcosahedronGeometry(1.5, 1);
  private geoLeafB = new THREE.IcosahedronGeometry(0.9, 1);
  private geoTrunk = new THREE.CylinderGeometry(0.12, 0.2, 2.2, 6);
  private geoEnsetTrunk = new THREE.CylinderGeometry(0.16, 0.24, 1.4, 7);
  private geoEnsetLeaf = new THREE.BoxGeometry(0.34, 0.04, 1.7);
  private geoTukulWall = new THREE.CylinderGeometry(1.5, 1.6, 1.7, 10);
  private geoTukulRoof = new THREE.ConeGeometry(2.05, 1.8, 10);

  private buildChunks() {
    for (let i = 0; i < CHUNK_COUNT; i++) {
      const group = new THREE.Group();
      group.position.z = -i * CHUNK_LEN;
      const chunk: Chunk = { group, decor: [] };
      this.populateChunk(chunk, i === 0);
      this.scene.add(group);
      this.chunks.push(chunk);
    }
  }

  private populateChunk(chunk: Chunk, isVillage: boolean) {
    // clear old decor
    for (const d of chunk.decor) chunk.group.remove(d);
    chunk.decor = [];

    // environment section: A coffee farm, B village, C river valley, D highlands, E countryside
    const theme = isVillage ? 1 : this.themeCursor++ % 5;
    const grassCols = [0x6fa83c, 0x79a83e, 0x5f9d45, 0x86b04a, 0x74a03a];
    const pathCols = [0x8a5a3b, 0x93684a, 0x7d5535, 0x8f6a44, 0x87603f];

    // section-tinted grass sides for smooth biome transitions
    const grass = new THREE.Mesh(new THREE.PlaneGeometry(240, CHUNK_LEN), this.matCached(grassCols[theme]));
    grass.rotation.x = -Math.PI / 2;
    grass.position.set(0, -0.02, 0);
    chunk.group.add(grass);
    chunk.decor.push(grass);

    // dirt path
    const shade = 0.92 + Math.random() * 0.14;
    const pc = new THREE.Color(pathCols[theme]).multiplyScalar(shade);
    const path = new THREE.Mesh(new THREE.PlaneGeometry(7.6, CHUNK_LEN), this.matCached(pc));
    path.rotation.x = -Math.PI / 2;
    path.position.set(0, 0.01, 0);
    chunk.group.add(path);
    chunk.decor.push(path);

    // worn wheel ruts between lanes — subtle depth, no markings
    const rutM = this.matCached(0x5f3d24);
    for (const rx of [-1.1, 1.1]) {
      const rut = new THREE.Mesh(new THREE.PlaneGeometry(0.22, CHUNK_LEN), rutM);
      rut.rotation.x = -Math.PI / 2;
      rut.position.set(rx, 0.018, 0);
      chunk.group.add(rut);
      chunk.decor.push(rut);
    }
    // soft dark edges
    for (const ex of [-3.55, 3.55]) {
      const edge = new THREE.Mesh(new THREE.PlaneGeometry(0.5, CHUNK_LEN), this.matCached(0x4e3018));
      edge.rotation.x = -Math.PI / 2;
      edge.position.set(ex, 0.016, 0);
      chunk.group.add(edge);
      chunk.decor.push(edge);
    }

    // mud decals
    const mudCount = 2 + Math.floor(Math.random() * 3);
    for (let i = 0; i < mudCount; i++) {
      const mud = new THREE.Mesh(
        new THREE.PlaneGeometry(2.4 + Math.random() * 2, 1.6 + Math.random() * 1.4),
        this.mudMat
      );
      mud.rotation.x = -Math.PI / 2;
      mud.rotation.z = Math.random() * Math.PI;
      mud.position.set((Math.random() - 0.5) * 5, 0.02, -Math.random() * CHUNK_LEN);
      chunk.group.add(mud);
      chunk.decor.push(mud);
    }

    const river = !isVillage && Math.random() < (theme === 2 ? 0.55 : theme === 4 ? 0.22 : 0.14);
    if (river) {
      const rz = -CHUNK_LEN * (0.3 + Math.random() * 0.4);
      const water = new THREE.Mesh(new THREE.PlaneGeometry(220, 9), this.waterMat);
      water.rotation.x = -Math.PI / 2;
      water.position.set(0, -0.35, rz);
      chunk.group.add(water);
      chunk.decor.push(water);
      // bridge planks over the path
      const plankM = this.matCached(0x8a5f34);
      for (let i = 0; i < 8; i++) {
        const p = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.14, 1.0), plankM);
        p.position.set(0, 0.06, rz - 4 + i * 1.12);
        chunk.group.add(p);
        chunk.decor.push(p);
      }
      const railM = this.matCached(0x5f3c1d);
      for (const sx of [-3.75, 3.75]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.5, 9), railM);
        rail.position.set(sx, 0.4, rz);
        chunk.group.add(rail);
        chunk.decor.push(rail);
        for (let i = 0; i < 4; i++) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.9, 0.16), railM);
          post.position.set(sx, 0.3, rz - 3.6 + i * 2.4);
          chunk.group.add(post);
          chunk.decor.push(post);
        }
      }
    }

    // side decorations — weighted by biome theme
    const count = Math.round((isVillage ? 8 : 10) * this.density) + 3;
    for (let i = 0; i < count; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (5.5 + Math.random() * 20);
      const z = -Math.random() * CHUNK_LEN;
      let prop: THREE.Group;
      if (isVillage && i < 4) {
        prop = this.makeTukul(0.9 + Math.random() * 0.35);
      } else {
        const r = Math.random();
        if (theme === 0) {
          // A — coffee farms & green hills
          if (r < 0.34) prop = this.makeCoffeeRow();
          else if (r < 0.54) prop = this.makeBush();
          else if (r < 0.68) prop = this.makeFence();
          else if (r < 0.82) prop = this.makeEnset();
          else prop = this.makeAcacia();
        } else if (theme === 1) {
          // B — tukul village & farmland
          if (r < 0.3) prop = this.makeTukul(0.8 + Math.random() * 0.4);
          else if (r < 0.48) prop = this.makeFence();
          else if (r < 0.64) prop = this.makeFlowers();
          else if (r < 0.8) prop = this.makeCoffeeRow();
          else prop = this.makeBush();
        } else if (theme === 2) {
          // C — river valley & bridges
          if (r < 0.34) prop = this.makeEnset();
          else if (r < 0.56) prop = this.makeAcacia();
          else if (r < 0.74) prop = this.makeBush();
          else if (r < 0.88) prop = this.makeFlowers();
          else prop = this.makeTukul(0.8 + Math.random() * 0.3);
        } else if (theme === 3) {
          // D — terraced highlands
          if (r < 0.32 && Math.abs(x) > 9) prop = this.makeTerrace();
          else if (r < 0.52) prop = this.makeOutcrop();
          else if (r < 0.74) prop = this.makeAcacia();
          else if (r < 0.9) prop = this.makeBush();
          else prop = this.makeFence();
        } else {
          // E — open countryside
          if (r < 0.26) prop = this.makeAcacia();
          else if (r < 0.46) prop = this.makeFlowers();
          else if (r < 0.64) prop = this.makeBush();
          else if (r < 0.8) prop = this.makeOutcrop();
          else if (r < 0.92) prop = this.makeTukul(0.8 + Math.random() * 0.3);
          else prop = this.makeCoffeeRow();
        }
      }
      prop.position.set(x, 0, z);
      prop.rotation.y = theme === 0 && (prop === chunk.decor[0] || Math.random() < 0.3) ? 0 : Math.random() * Math.PI * 2;
      chunk.group.add(prop);
      chunk.decor.push(prop);
    }

    if (isVillage) {
      const fire = this.makeCampfire();
      fire.position.set(3.4, 0, -14);
      chunk.group.add(fire);
      chunk.decor.push(fire);
      for (let i = 0; i < 3; i++) {
        const j = this.makeJebena();
        j.position.set(-3.6 + i * 0.7, 0, -10 - i * 0.6);
        chunk.group.add(j);
        chunk.decor.push(j);
      }
    }
  }

  /* --------------------------- player ---------------------------- */
  private buildPlayer(v: RunnerVariant) {
    if (this.player) this.scene.remove(this.player);
    const skin = this.mat(v.skin);
    const shirt = this.mat(v.shirt);
    const sleeves = this.mat(v.sleeves);
    const shorts = this.mat(v.shorts);
    const shoe = this.mat(v.shoe);
    const hair = this.mat(0x17110c);

    const player = new THREE.Group();
    const root = new THREE.Group();
    player.add(root);

    const body = new THREE.Group();
    body.position.y = 0.98;
    root.add(body);

    // torso
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.56, 0.26), shirt);
    torso.position.y = 0.28;
    body.add(torso);
    // sash (tilet) across chest
    const sash = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.3), new THREE.MeshLambertMaterial({ map: texTilet() }));
    sash.position.set(0, 0.3, 0);
    sash.rotation.z = 0.6;
    body.add(sash);
    const sashHip = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.16, 0.32), new THREE.MeshLambertMaterial({ map: texTilet() }));
    sashHip.position.set(0, -0.02, 0);
    body.add(sashHip);
    // flag patch
    const patch = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.08), new THREE.MeshLambertMaterial({ map: texFlag() }));
    patch.position.set(0.13, 0.44, 0.135);
    body.add(patch);
    // shorts
    const hip = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.26, 0.27), shorts);
    hip.position.y = -0.08;
    body.add(hip);

    // head
    const headG = new THREE.Group();
    headG.position.y = 0.72;
    body.add(headG);
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.12, 8), skin);
    neck.position.y = -0.12;
    headG.add(neck);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 16, 14), skin);
    head.scale.set(0.95, 1.05, 0.98);
    headG.add(head);
    const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.195, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.52), hair);
    hairCap.position.y = 0.02;
    hairCap.scale.set(0.97, 1.05, 1);
    headG.add(hairCap);
    // ears
    for (const sx of [-1, 1]) {
      const ear = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), skin);
      ear.position.set(sx * 0.18, 0, 0);
      headG.add(ear);
    }
    // glasses
    const glassM = this.mat(0x20242c);
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.025, 0.02), glassM);
    frame.position.set(0, 0.03, -0.185);
    headG.add(frame);
    for (const sx of [-1, 1]) {
      const lens = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.075, 0.015), new THREE.MeshLambertMaterial({ color: 0x9fb8c8, transparent: true, opacity: 0.55 }));
      lens.position.set(sx * 0.08, 0.02, -0.19);
      headG.add(lens);
    }
    // eyes + smile
    for (const sx of [-1, 1]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.022, 6, 6), this.mat(0xffffff));
      eye.position.set(sx * 0.075, 0.02, -0.175);
      headG.add(eye);
    }

    // arms (pivot at shoulder) — character faces -Z
    const mkArm = (sx: number) => {
      const sh = new THREE.Group();
      sh.position.set(sx * 0.28, 0.5, 0);
      body.add(sh);
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.24, 3, 8), sleeves);
      upper.position.y = -0.16;
      sh.add(upper);
      const elb = new THREE.Group();
      elb.position.y = -0.32;
      sh.add(elb);
      const fore = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.22, 3, 8), skin);
      fore.position.y = -0.14;
      elb.add(fore);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), skin);
      hand.position.y = -0.28;
      elb.add(hand);
      return { sh, elb };
    };
    const armL = mkArm(-1);
    const armR = mkArm(1);

    // legs (pivot at hip)
    const mkLeg = (sx: number) => {
      const hipP = new THREE.Group();
      hipP.position.set(sx * 0.12, -0.16, 0);
      body.add(hipP);
      const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.26, 3, 8), sx < 0 ? shorts : shorts);
      thigh.position.y = -0.17;
      hipP.add(thigh);
      const knee = new THREE.Group();
      knee.position.y = -0.36;
      hipP.add(knee);
      const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.26, 3, 8), skin);
      shin.position.y = -0.16;
      knee.add(shin);
      const foot = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.09, 0.28), shoe);
      foot.position.set(0, -0.36, -0.06);
      knee.add(foot);
      const sole = new THREE.Mesh(new THREE.BoxGeometry(0.135, 0.035, 0.3), this.mat(0xf2efe6));
      sole.position.set(0, -0.4, -0.06);
      knee.add(sole);
      return { hipP, knee };
    };
    const legL = mkLeg(-1);
    const legR = mkLeg(1);

    this.pShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1.3, 1.3),
      new THREE.MeshBasicMaterial({ map: this.shadowTex, transparent: true, depthWrite: false })
    );
    this.pShadow.rotation.x = -Math.PI / 2;
    this.pShadow.position.y = 0.03;
    player.add(this.pShadow);

    this.player = player;
    this.pRoot = root;
    this.pBody = body;
    this.pHipL = legL.hipP; this.pHipR = legR.hipP;
    this.pKneeL = legL.knee; this.pKneeR = legR.knee;
    this.pShL = armL.sh; this.pShR = armR.sh;
    this.pElbL = armL.elb; this.pElbR = armR.elb;

    this.scene.add(player);
  }

  /* --------------------------- pools ----------------------------- */
  private buildPools() {
    const types: Obstacle["type"][] = ["low", "high", "block", "goat"];
    for (let i = 0; i < 14; i++) {
      const type = types[i % types.length];
      let group: THREE.Group;
      if (type === "low") group = this.makeLog();
      else if (type === "high") group = this.makeBranch();
      else if (type === "goat") group = this.makeGoat();
      else group = Math.random() > 0.5 ? this.makeRock() : this.makeCart();
      group.visible = false;
      this.scene.add(group);
      this.obstacles.push({ group, type, lane: 1, active: false, goatHead: group.userData.head });
    }

    // coins: instanced coffee cherries (golden beans)
    const geo = new THREE.SphereGeometry(0.22, 10, 8);
    const m = new THREE.MeshLambertMaterial({ color: 0xffc23e, emissive: 0x8a4a00, emissiveIntensity: 0.6 });
    this.coins = new THREE.InstancedMesh(geo, m, 140);
    this.coins.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.coins.frustumCulled = false;
    this.scene.add(this.coins);
    for (let i = 0; i < 140; i++) {
      this.coinData.push({ x: 0, y: -999, z: 0, active: false, ph: 0 });
      this.dummy.position.set(0, -999, 0);
      this.dummy.scale.setScalar(0.001);
      this.dummy.updateMatrix();
      this.coins.setMatrixAt(i, this.dummy.matrix);
    }

    this.dust = new Particles(160, 0.5, 0xc89a66, 2.0, texSoft(), THREE.NormalBlending);
    this.spark = new Particles(180, 0.55, 0xffd24a, 3.5, texSoft(), THREE.AdditiveBlending);
    this.scene.add(this.dust.points, this.spark.points);

    // golden Meskel coins (rare collectible)
    const gemGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.07, 20);
    const gemMat = new THREE.MeshLambertMaterial({ color: 0xffd23e, emissive: 0xb87400, emissiveIntensity: 0.9 });
    this.gems = new THREE.InstancedMesh(gemGeo, gemMat, 10);
    this.gems.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.gems.frustumCulled = false;
    this.scene.add(this.gems);
    for (let i = 0; i < 10; i++) {
      this.gemData.push({ x: 0, y: -999, z: 0, active: false, ph: 0 });
      this.dummy.position.set(0, -999, 0);
      this.dummy.scale.setScalar(0.001);
      this.dummy.updateMatrix();
      this.gems.setMatrixAt(i, this.dummy.matrix);
    }

    // landing shockwave rings
    for (let i = 0; i < 5; i++) {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.35, 0.5, 24),
        new THREE.MeshBasicMaterial({ color: 0xffe0a8, transparent: true, opacity: 0, depthWrite: false })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.04;
      ring.visible = false;
      this.scene.add(ring);
      this.rings.push({ m: ring, t: 0 });
    }

    // drifting clouds
    const cloudTex = texCloud();
    for (let i = 0; i < 6; i++) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: cloudTex, transparent: true, opacity: 0.55, depthWrite: false, fog: false }));
      sp.scale.set(26 + Math.random() * 22, 9 + Math.random() * 6, 1);
      sp.position.set(-90 + Math.random() * 180, 30 + Math.random() * 16, -180 - Math.random() * 80);
      this.scene.add(sp);
      this.clouds.push(sp);
    }

    // distant birds
    for (let i = 0; i < 3; i++) {
      const g = new THREE.Group();
      const wingGeo = new THREE.PlaneGeometry(0.9, 0.28);
      const wingM = new THREE.MeshBasicMaterial({ color: 0x3a2a1c, side: THREE.DoubleSide, fog: false });
      const wL = new THREE.Mesh(wingGeo, wingM);
      wL.position.x = -0.45;
      const wR = new THREE.Mesh(wingGeo, wingM);
      wR.position.x = 0.45;
      g.add(wL, wR);
      g.position.set(-40 + i * 40, 24 + i * 3, -160);
      g.scale.setScalar(1.6);
      this.scene.add(g);
      this.birds.push({ g, wL, wR, ph: i * 2.1 });
    }
  }

  private spawnRing(x: number, z: number, big = false) {
    const r = this.rings.find((rr) => rr.t <= 0);
    if (!r) return;
    r.t = big ? 0.55 : 0.38;
    r.m.visible = true;
    r.m.position.set(x, 0.045, z);
    r.m.scale.setScalar(big ? 1.6 : 0.8);
    (r.m.material as THREE.MeshBasicMaterial).opacity = 0.75;
  }

  private updateAmbient(dt: number) {
    for (const c of this.clouds) {
      c.position.x += dt * 1.4;
      if (c.position.x > 110) c.position.x = -110;
    }
    for (const b of this.birds) {
      const flap = Math.sin(this.time * 7 + b.ph) * 0.7;
      b.wL.rotation.y = flap;
      b.wR.rotation.y = -flap;
      b.g.position.x += Math.sin(this.time * 0.25 + b.ph) * dt * 3;
      b.g.position.y += Math.sin(this.time * 0.6 + b.ph) * dt * 0.6;
    }
    for (const r of this.rings) {
      if (r.t <= 0) continue;
      r.t -= dt;
      const grow = dt * 7;
      r.m.scale.setScalar(r.m.scale.x + grow);
      (r.m.material as THREE.MeshBasicMaterial).opacity = Math.max(0, r.t / 0.4) * 0.7;
      if (r.t <= 0) r.m.visible = false;
    }
  }

  /* --------------------------- input ----------------------------- */
  private onKey = (e: KeyboardEvent) => {
    const k = e.key;
    if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", " "].includes(k)) e.preventDefault();
    if (this.state === "running") {
      if (k === "ArrowLeft" || k === "a" || k === "A") this.moveLane(-1);
      else if (k === "ArrowRight" || k === "d" || k === "D") this.moveLane(1);
      else if (k === "ArrowUp" || k === "w" || k === "W" || k === " ") this.doJump();
      else if (k === "ArrowDown" || k === "s" || k === "S") this.doSlide();
      else if (k === "Escape" || k === "p" || k === "P") this.pause();
    } else if (this.state === "paused" && (k === "Escape" || k === "p" || k === "P")) {
      this.resume();
    }
  };

  private pDown = { x: 0, y: 0, t: 0, on: false };
  private onPtrDown = (e: PointerEvent) => {
    this.audio.unlock();
    this.pDown = { x: e.clientX, y: e.clientY, t: performance.now(), on: true };
  };
  private onPtrUp = (e: PointerEvent) => {
    if (!this.pDown.on || this.state !== "running") { this.pDown.on = false; return; }
    const dx = e.clientX - this.pDown.x;
    const dy = e.clientY - this.pDown.y;
    const adx = Math.abs(dx), ady = Math.abs(dy);
    if (Math.max(adx, ady) < 18) {
      this.doJump();
    } else if (adx > ady) {
      this.moveLane(dx > 0 ? 1 : -1);
    } else if (dy < 0) {
      this.doJump();
    } else {
      this.doSlide();
    }
    this.pDown.on = false;
  };

  private bindInput() {
    window.addEventListener("keydown", this.onKey);
    this.renderer.domElement.addEventListener("pointerdown", this.onPtrDown);
    window.addEventListener("pointerup", this.onPtrUp);
    window.addEventListener("resize", this.onResize);
    document.addEventListener("visibilitychange", this.onVis);
  }

  private onResize = () => {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private onVis = () => {
    if (document.hidden && this.state === "running") this.pause();
  };

  /* ------------------------- public API -------------------------- */
  moveLane(dir: number) {
    const next = Math.max(0, Math.min(2, this.lane + dir));
    if (next !== this.lane) {
      this.lane = next;
      this.audio.lane();
    }
  }
  doJump() {
    if (this.py <= 0.01 && this.sliding <= 0) {
      this.vy = 9.4;
      this.audio.jump();
      this.dust.burst(this.px, 0.1, 0, 8, 2.2, 0.6);
    } else {
      this.jumpQueued = true;
    }
  }
  doSlide() {
    if (this.py > 0.01) {
      this.vy = -14; // fast fall
      this.audio.slide();
    } else {
      this.sliding = 0.72;
      this.audio.slide();
      this.dust.burst(this.px, 0.15, 0.3, 6, 1.6, 0.3);
    }
  }

  setRunner(i: number) {
    this.buildPlayer(RUNNERS[i]);
    this.syncPlayerTransform();
  }

  startRun() {
    this.resetWorld();
    this.state = "running";
    this.cb.onState("running");
    this.pRoot.rotation.y = 0;
    this.speed = 10;
    this.audio.unlock();
    // seed early patterns so the action starts within seconds
    this.spawnPattern(-75);
    this.spawnPattern(-120);
    this.spawnPattern(-165);
    this.nextSpawn = 50;
  }

  private resetWorld() {
    this.distance = 0;
    this.beans = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.gemsCollected = 0;
    this.bonus = 0;
    this.lastMilestone = 0;
    this.airBlend = 0;
    this.slideBlend = 0;
    this.squash = 0;
    this.lane = 1;
    this.px = 0; this.py = 0; this.vy = 0;
    this.sliding = 0;
    this.crashT = 0;
    this.shake = 0;
    this.speed = 0;
    this.nextSpawn = 40;
    for (const o of this.obstacles) { o.active = false; o.group.visible = false; }
    for (const c of this.coinData) { c.active = false; c.y = -999; }
    for (const g of this.gemData) { g.active = false; g.y = -999; }
    for (const r of this.rings) { r.t = 0; r.m.visible = false; }
    // reset chunks
    this.chunks.forEach((ch, i) => {
      ch.group.position.z = -i * CHUNK_LEN;
      this.populateChunk(ch, i === 0);
    });
    this.pRoot.rotation.set(0, 0, 0);
    this.pRoot.position.set(0, 0, 0);
    this.syncPlayerTransform();
  }

  pause() {
    if (this.state !== "running") return;
    this.state = "paused";
    this.cb.onState("paused");
    this.audio.pauseBlip();
  }
  resume() {
    if (this.state !== "paused") return;
    this.state = "running";
    this.cb.onState("running");
    this.audio.pauseBlip();
    this.clock.getDelta();
  }
  toMenu() {
    this.state = "menu";
    this.cb.onState("menu");
    this.resetWorld();
    this.pRoot.rotation.y = Math.PI;
  }

  applyQuality(q: Quality) {
    this.quality = q;
    const dpr = window.devicePixelRatio || 1;
    if (q === "high") { this.renderer.setPixelRatio(Math.min(dpr, 2)); this.density = 1; }
    else if (q === "medium") { this.renderer.setPixelRatio(Math.min(dpr, 1.5)); this.density = 0.7; }
    else { this.renderer.setPixelRatio(1); this.density = 0.45; }
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKey);
    this.renderer.domElement.removeEventListener("pointerdown", this.onPtrDown);
    window.removeEventListener("pointerup", this.onPtrUp);
    window.removeEventListener("resize", this.onResize);
    document.removeEventListener("visibilitychange", this.onVis);
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }

  /* --------------------------- gameplay -------------------------- */
  private spawnPattern(atZ: number = SPAWN_Z) {
    const roll = Math.random();
    const freeLane = Math.floor(Math.random() * 3);
    const usedLanes = new Set<number>();

    const place = (type: Obstacle["type"], lane: number) => {
      const o = this.obstacles.find((ob) => !ob.active && ob.type === type) || this.obstacles.find((ob) => !ob.active);
      if (!o) return;
      o.active = true;
      o.group.visible = true;
      o.lane = lane;
      o.group.position.set(LANES[lane], 0, atZ);
      o.group.rotation.y = type === "goat" ? (Math.random() > 0.5 ? 0.4 : -0.4) : 0;
      o.group.userData.near = false;
      usedLanes.add(lane);
    };

    if (roll < 0.22) {
      place("low", freeLane === 0 ? 1 + Math.floor(Math.random() * 2) : Math.floor(Math.random() * 3));
    } else if (roll < 0.38) {
      place("high", Math.floor(Math.random() * 3));
    } else if (roll < 0.58) {
      const blockLane = freeLane === 0 ? 2 : 0;
      place("block", blockLane);
      if (Math.random() > 0.5) {
        const other = [0, 1, 2].find((l) => l !== freeLane && l !== blockLane)!;
        place(Math.random() > 0.5 ? "low" : "goat", other);
      }
    } else if (roll < 0.75) {
      place("goat", Math.floor(Math.random() * 3));
    } else {
      // double block — one lane always free
      const lanes = [0, 1, 2].filter((l) => l !== freeLane);
      place("block", lanes[0]);
      place(Math.random() > 0.4 ? "block" : "low", lanes[1]);
    }

    // coins on a free lane — straight, arc, or zigzag weave
    if (Math.random() < 0.75) {
      const cl = [0, 1, 2].find((l) => !usedLanes.has(l)) ?? freeLane;
      const zigAlt = [0, 1, 2].find((l) => l !== cl && !usedLanes.has(l));
      const n = 5 + Math.floor(Math.random() * 4);
      const arc = Math.random() < 0.28;
      const zig = !arc && zigAlt !== undefined && Math.random() < 0.35;
      for (let i = 0; i < n; i++) {
        const c = this.coinData[this.coinCursor];
        this.coinCursor = (this.coinCursor + 1) % this.coinData.length;
        c.active = true;
        const lane = zig ? (i % 2 === 0 ? cl : zigAlt!) : cl;
        c.x = LANES[lane];
        c.z = atZ - i * 2.3;
        c.y = arc ? 0.9 + Math.sin((i / (n - 1)) * Math.PI) * 1.2 : 0.95;
        c.ph = Math.random() * Math.PI * 2;
      }
    }

    // rare golden Meskel coin
    if (Math.random() < 0.09) {
      const gl = [0, 1, 2].find((l) => !usedLanes.has(l)) ?? freeLane;
      const g = this.gemData.find((d) => !d.active);
      if (g) {
        g.active = true;
        g.x = LANES[gl];
        g.z = atZ - 6;
        g.y = 1.0;
        g.ph = Math.random() * Math.PI * 2;
      }
    }
  }

  private crash() {
    if (this.state !== "running") return;
    this.state = "over";
    this.crashT = 0;
    this.shake = 1;
    this.audio.crash();
    this.audio.stopMusic();
    this.dust.burst(this.px, 0.8, 0, 26, 5, 0.8);
    this.spark.burst(this.px, 1, 0, 14, 4, 0.6);
  }

  private finishRun() {
    const dist = Math.floor(this.distance / 5);
    const score = dist + this.beans * 3 + this.gemsCollected * 25 + this.bonus;
    this.cb.onGameOver({ score, dist, beans: this.beans, gems: this.gemsCollected });
  }

  /* ---------------------------- loop ----------------------------- */
  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.time += dt;

    if (this.state === "running") this.updateRun(dt);
    else if (this.state === "over") this.updateCrash(dt);
    else if (this.state === "menu") this.updateMenu(dt);

    if (this.state === "running") this.audio.ensureMusic("run");
    else if (this.state === "menu") this.audio.ensureMusic("menu");
    else this.audio.stopMusic();

    this.updateWorldScroll(this.state === "running" || this.state === "over" ? this.speed * dt : 0);
    this.dust.update(dt);
    this.spark.update(dt);
    this.updateAmbient(dt);
    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
  };

  private updateRun(dt: number) {
    // smooth ease-in difficulty curve
    this.speed = Math.min(38, this.speed + dt * (0.4 + this.speed * 0.005));
    this.distance += this.speed * dt;

    // spawn with reaction-time-based spacing + occasional breather
    this.nextSpawn -= this.speed * dt;
    if (this.nextSpawn <= 0) {
      this.spawnPattern();
      const reaction = Math.max(0.72, 1.05 - this.distance * 0.000015);
      const breather = Math.random() < 0.12 ? 1.9 : 1;
      this.nextSpawn = this.speed * reaction * (0.85 + Math.random() * 0.55) * breather;
    }

    // lateral — snappier, frame-rate independent
    const targetX = LANES[this.lane];
    this.px += (targetX - this.px) * (1 - Math.exp(-dt * 14));

    // vertical
    const airborne = this.py > 0 || this.vy > 0;
    if (airborne) {
      this.vy -= 24 * dt;
      this.py += this.vy * dt;
      if (this.py <= 0) {
        this.py = 0; this.vy = 0;
        this.squash = 1;
        this.audio.land();
        this.spawnRing(this.px, 0);
        this.dust.burst(this.px, 0.1, 0, 10, 2.4, 0.5);
        if (this.jumpQueued) { this.jumpQueued = false; this.doJump(); }
      }
    }
    if (this.sliding > 0) {
      this.sliding -= dt;
      if (this.sliding <= 0 && this.jumpQueued) { this.jumpQueued = false; this.doJump(); }
    }

    // animation blend factors
    this.airBlend += ((airborne ? 1 : 0) - this.airBlend) * Math.min(1, dt * 14);
    this.slideBlend += ((this.sliding > 0 ? 1 : 0) - this.slideBlend) * Math.min(1, dt * 16);
    this.squash = Math.max(0, this.squash - dt * 5);

    // step-synced footstep dust + sound
    const stepPh = this.distance * 0.55;
    const sgn = Math.sin(stepPh) >= 0 ? 1 : -1;
    if (sgn !== this.lastStepSign && this.py <= 0 && this.sliding <= 0) {
      this.lastStepSign = sgn;
      this.stepAlt = !this.stepAlt;
      this.audio.footstep(this.stepAlt);
      this.dust.burst(this.px + (this.stepAlt ? 0.15 : -0.15), 0.06, 0.35, 2, 0.8, 0.2);
    } else if (this.py <= 0 && Math.random() < 0.12) {
      this.dust.burst(this.px + (Math.random() - 0.5) * 0.3, 0.08, 0.4, 1, 0.9, 0.25);
    }

    // combo timer
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.combo = 0;
    }

    // milestone reward every 25 beans
    if (this.beans > 0 && this.beans % 25 === 0 && this.beans !== this.lastMilestone) {
      this.lastMilestone = this.beans;
      this.bonus += 50;
      this.audio.milestone();
      this.spark.burst(this.px, 1.2, 0, 26, 4, 0.9);
      this.spawnRing(this.px, 0, true);
      this.cb.onToast("Coffee Boost!  +50");
    }

    this.animateRunner(dt, true);
    this.checkCollisions();
    this.syncPlayerTransform();

    const dist = Math.floor(this.distance / 5);
    this.cb.onHud(dist + this.beans * 3 + this.gemsCollected * 25 + this.bonus, dist, this.beans, this.gemsCollected);
  }

  private updateCrash(dt: number) {
    this.speed = Math.max(0, this.speed - dt * 30);
    this.crashT += dt;
    // tumble, then settle face-down
    if (this.crashT < 0.75) {
      this.pRoot.rotation.x -= dt * 9;
    } else {
      this.pRoot.rotation.x += (-1.5 - this.pRoot.rotation.x) * Math.min(1, dt * 8);
    }
    if (this.crashT > 0.9) {
      this.crashT = -999; // fire once
      this.audio.gameOver();
      this.finishRun();
    }
  }

  private updateMenu(dt: number) {
    this.animateRunner(dt, false);
    this.syncPlayerTransform();
    const flame = this.scene.getObjectByName("flame");
    if (flame) {
      flame.scale.setScalar(0.85 + Math.sin(this.time * 9) * 0.18);
      flame.rotation.y += dt * 2;
    }
  }

  private updateWorldScroll(dz: number) {
    if (dz <= 0 && this.state !== "menu") {
      // still animate decor (water shimmer etc.) — nothing to scroll
    }
    for (const ch of this.chunks) {
      ch.group.position.z += dz;
      if (ch.group.position.z > 50) {
        ch.group.position.z -= CHUNK_COUNT * CHUNK_LEN;
        this.populateChunk(ch, false);
      }
    }
    for (const o of this.obstacles) {
      if (!o.active) continue;
      o.group.position.z += dz;
      if (o.goatHead) o.goatHead.rotation.x = Math.sin(this.time * 3 + o.lane) * 0.18;
      if (o.group.position.z > 12) { o.active = false; o.group.visible = false; }
    }
    // coins
    let any = false;
    for (let i = 0; i < this.coinData.length; i++) {
      const c = this.coinData[i];
      if (!c.active) {
        this.dummy.position.set(0, -999, 0);
        this.dummy.scale.setScalar(0.001);
      } else {
        any = true;
        c.z += dz;
        const bob = Math.sin(this.time * 4 + c.ph) * 0.08;
        this.dummy.position.set(c.x, c.y + bob, c.z);
        this.dummy.rotation.set(0, this.time * 3 + c.ph, 0);
        const s = c.z > 6 ? 0.001 : 1;
        this.dummy.scale.setScalar(s);
        if (c.z > 8) c.active = false;
      }
      this.dummy.updateMatrix();
      this.coins.setMatrixAt(i, this.dummy.matrix);
    }
    if (any || dz > 0) this.coins.instanceMatrix.needsUpdate = true;

    // gems
    let gAny = false;
    for (let i = 0; i < this.gemData.length; i++) {
      const g = this.gemData[i];
      if (!g.active) {
        this.dummy.position.set(0, -999, 0);
        this.dummy.scale.setScalar(0.001);
      } else {
        gAny = true;
        g.z += dz;
        const bob = Math.sin(this.time * 3 + g.ph) * 0.1;
        this.dummy.position.set(g.x, g.y + bob, g.z);
        this.dummy.rotation.set(Math.PI / 2, 0, this.time * 2.4 + g.ph);
        this.dummy.scale.setScalar(g.z > 6 ? 0.001 : 1.15 + Math.sin(this.time * 5 + g.ph) * 0.12);
        if (g.z > 8) g.active = false;
      }
      this.dummy.updateMatrix();
      this.gems.setMatrixAt(i, this.dummy.matrix);
    }
    if (gAny || dz > 0) this.gems.instanceMatrix.needsUpdate = true;
  }

  private checkCollisions() {
    // grace period at run start
    if (this.distance < 8) return;
    // speed-scaled z window prevents tunneling at high speed
    const wz = Math.max(0.95, this.speed * 0.034);
    const slideT = this.slideBlend > 0.35;
    for (const o of this.obstacles) {
      if (!o.active) continue;
      const z = o.group.position.z;
      const dx = Math.abs(o.group.position.x - this.px);
      if (z > -wz && z < wz * 0.85 && dx < 0.98) {
        if (o.type === "low" && this.py < 0.5) return this.crash();
        if (o.type === "goat" && this.py < 0.55) return this.crash();
        if (o.type === "high" && !slideT) return this.crash();
        if (o.type === "block") return this.crash();
      } else if (!o.group.userData.near && z > 0.95 && z < 1.6 && dx >= 0.98 && dx < 1.9) {
        // close shave — reward the near miss with a whoosh
        o.group.userData.near = true;
        this.audio.whoosh();
        this.spark.burst(o.group.position.x, 1.0, z, 4, 1.3, 0.3);
      }
    }
    // golden coins
    for (const g of this.gemData) {
      if (!g.active) continue;
      if (Math.abs(g.z) < 1.2 && Math.abs(g.x - this.px) < 1.1 && Math.abs(g.y - (this.py + 0.9)) < 1.5) {
        g.active = false;
        this.gemsCollected++;
        this.audio.gem();
        this.spark.burst(g.x, g.y, g.z, 20, 3.4, 0.7);
        this.spawnRing(this.px, 0, true);
        this.cb.onToast("Meskel Coin!  +25");
      }
    }
    // coins
    for (const c of this.coinData) {
      if (!c.active) continue;
      if (Math.abs(c.z) < 1.1 && Math.abs(c.x - this.px) < 1.0 && Math.abs(c.y - (this.py + 0.9)) < 1.3) {
        c.active = false;
        this.beans++;
        this.combo = Math.min(5, this.combo + 1);
        this.comboTimer = 2;
        this.audio.bean(this.combo - 1);
        this.spark.burst(c.x, c.y, c.z, 8, 2.6, 0.5);
      }
    }
  }

  private syncPlayerTransform() {
    this.player.position.set(this.px, this.py, 0);
    const tilt = (LANES[this.lane] - this.px) * 0.12;
    this.pRoot.rotation.z = this.state === "menu" ? 0 : -tilt;
    this.pShadow.position.set(0, 0.03 - this.py, 0);
    const shScale = Math.max(0.35, 1 - this.py * 0.22);
    this.pShadow.scale.setScalar(shScale);
    (this.pShadow.material as THREE.MeshBasicMaterial).opacity = 0.9 * shScale;
  }

  private animateRunner(dt: number, running: boolean) {
    const t = this.time;
    const mix = (a: number, b: number, f: number) => a + (b - a) * f;

    if (!running) {
      // idle breathing + friendly wave (menu)
      const b = Math.sin(t * 2.2) * 0.02;
      this.pBody.position.y = 0.98 + b;
      this.pBody.rotation.x = 0;
      this.pBody.scale.set(1, 1, 1);
      this.pRoot.rotation.x = 0;
      this.pHipL.rotation.x = 0; this.pHipR.rotation.x = 0;
      this.pKneeL.rotation.x = 0; this.pKneeR.rotation.x = 0;
      const wave = Math.max(0, Math.sin(t * 0.55));
      this.pShR.rotation.x = -wave * 2.6;
      this.pShR.rotation.z = wave * 0.5;
      this.pElbR.rotation.x = -wave * 0.6;
      this.pElbR.rotation.z = wave > 0.5 ? Math.sin(t * 9) * 0.5 * wave : 0;
      this.pShL.rotation.x = 0; this.pShL.rotation.z = 0;
      this.pElbL.rotation.x = 0; this.pElbL.rotation.z = 0;
      void dt;
      return;
    }

    const ph = this.distance * 0.55;
    const amp = Math.min(1, this.speed / 14);
    const a = this.airBlend, s = this.slideBlend;

    // run / jump / slide pose targets
    const rHL = Math.sin(ph) * 0.95 * amp, rHR = Math.sin(ph + Math.PI) * 0.95 * amp;
    const rKL = Math.max(0, Math.sin(ph + 0.9)) * 1.05 * amp;
    const rKR = Math.max(0, Math.sin(ph + Math.PI + 0.9)) * 1.05 * amp;
    const rSL = Math.sin(ph + Math.PI) * 0.85 * amp, rSR = Math.sin(ph) * 0.85 * amp;
    const rEL = -0.75 - Math.max(0, Math.sin(ph)) * 0.55 * amp;
    const rER = -0.75 - Math.max(0, Math.sin(ph + Math.PI)) * 0.55 * amp;

    const hipL = mix(mix(rHL, -0.95, a), -1.3, s);
    const hipR = mix(mix(rHR, -0.6, a), -1.1, s);
    const kneeL = mix(mix(rKL, 1.25, a), 0.4, s);
    const kneeR = mix(mix(rKR, 0.9, a), 0.5, s);
    const shL = mix(mix(rSL, -2.4, a), -0.5, s);
    const shR = mix(mix(rSR, -2.4, a), -0.5, s);
    const elbL = mix(mix(rEL, -0.3, a), -0.4, s);
    const elbR = mix(mix(rER, -0.3, a), -0.4, s);

    this.pHipL.rotation.x = hipL; this.pHipR.rotation.x = hipR;
    this.pKneeL.rotation.x = kneeL; this.pKneeR.rotation.x = kneeR;
    this.pShL.rotation.x = shL; this.pShR.rotation.x = shR;
    this.pShL.rotation.z = 0; this.pShR.rotation.z = 0;
    this.pElbL.rotation.x = elbL; this.pElbR.rotation.x = elbR;
    this.pElbL.rotation.z = 0; this.pElbR.rotation.z = 0;

    const bob = Math.abs(Math.sin(ph)) * 0.07 * amp;
    this.pBody.position.y = mix(mix(0.98 + bob, 1.0, a), 0.62, s);
    this.pBody.rotation.x = mix(mix(0.12, 0.2, a), -0.9, s);
    this.pBody.rotation.y = Math.sin(ph) * 0.09 * amp * (1 - a) * (1 - s);
    this.pRoot.rotation.x = mix(0, -0.5, s);

    // landing squash & stretch
    const sq = this.squash;
    this.pBody.scale.set(1 + sq * 0.14, 1 - sq * 0.24, 1 + sq * 0.14);
  }

  private updateCamera(dt: number) {
    this.shake = Math.max(0, this.shake - dt * 1.6);
    const sx = (Math.random() - 0.5) * this.shake * 0.5;
    const sy = (Math.random() - 0.5) * this.shake * 0.4;

    if (this.state === "menu" || (this.state !== "running" && this.state !== "over" && this.state !== "paused")) {
      // portrait phones: frame the runner left so the menu never overlaps him
      const portrait = this.camera.aspect < 0.85;
      const t = this.time;
      this.camera.position.set(
        (portrait ? -2.3 : -3.1) + Math.sin(t * 0.18) * 0.5 + sx,
        2.05 + sy,
        portrait ? 4.5 : 3.9
      );
      this.camera.lookAt(portrait ? 1.15 : 0.3, 1.25, -1.5);
      return;
    }
    // running / paused / over camera with subtle stride bob
    this.camX += (this.px * 0.5 - this.camX) * Math.min(1, dt * 6);
    const fovTarget = 62 + Math.min(10, this.speed * 0.22);
    this.camera.fov += (fovTarget - this.camera.fov) * Math.min(1, dt * 3);
    this.camera.updateProjectionMatrix();
    const bob = Math.sin(this.distance * 0.55) * 0.05 * Math.min(1, this.speed / 22);
    this.camera.position.set(this.camX + sx, 4.5 + this.py * 0.16 + bob + sy, 7.6);
    this.camera.lookAt(this.camX * 1.2, 1.5 + this.py * 0.25, -10);
  }
}
