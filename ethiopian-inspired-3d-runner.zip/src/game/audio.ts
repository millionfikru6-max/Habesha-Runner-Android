/* Procedural WebAudio sound engine — no external assets. */

export type MusicMode = "menu" | "run";

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicTimer: number | null = null;
  private nextNoteTime = 0;
  private step = 0;
  private musicMode: MusicMode | null = null;
  sfxOn = true;
  musicOn = true;
  sfxVol = 0.9;
  musicVol = 0.7;

  /** Must be called from a user gesture. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.sfxVol;
      this.sfxGain.connect(this.master);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicVol * 0.42;
      this.musicGain.connect(this.master);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setSfx(on: boolean) {
    this.sfxOn = on;
  }
  setMusic(on: boolean) {
    this.musicOn = on;
    if (!on) this.stopMusic();
  }
  setSfxVol(v: number) {
    this.sfxVol = v;
    if (this.sfxGain) this.sfxGain.gain.value = v;
  }
  setMusicVol(v: number) {
    this.musicVol = v;
    if (this.musicGain) this.musicGain.gain.value = v * 0.42;
  }

  /** Start or seamlessly switch the music theme for the given mode. */
  ensureMusic(mode: MusicMode) {
    if (!this.musicOn || !this.ctx) {
      if (this.musicTimer !== null) this.stopMusic();
      return;
    }
    if (this.musicMode === mode && this.musicTimer !== null) return;
    this.stopMusic();
    this.startMusic(mode);
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    when = 0,
    glideTo?: number,
    dest?: GainNode
  ) {
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime + when;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (glideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, glideTo), t + dur);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(g);
    g.connect(dest ?? this.sfxGain);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  private noise(dur: number, vol: number, filterFreq: number, when = 0) {
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime + when;
    const len = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = filterFreq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.sfxGain);
    src.start(t);
  }

  click() {
    if (!this.sfxOn) return;
    this.tone(660, 0.08, "square", 0.12);
    this.tone(990, 0.06, "square", 0.08, 0.03);
  }
  jump() {
    if (!this.sfxOn) return;
    this.tone(300, 0.28, "sine", 0.25, 0, 720);
    this.tone(520, 0.18, "triangle", 0.12, 0.02, 900);
  }
  slide() {
    if (!this.sfxOn) return;
    this.noise(0.22, 0.2, 900);
    this.tone(420, 0.2, "sawtooth", 0.08, 0, 140);
  }
  lane() {
    if (!this.sfxOn) return;
    this.tone(500, 0.06, "triangle", 0.1, 0, 620);
  }
  bean(combo: number) {
    if (!this.sfxOn) return;
    const scale = [523.25, 587.33, 659.25, 783.99, 880.0]; // Tizita-ish pentatonic
    const n = scale[Math.min(combo, scale.length - 1)];
    this.tone(n, 0.14, "triangle", 0.2);
    this.tone(n * 2, 0.1, "sine", 0.1, 0.02);
  }
  crash() {
    if (!this.sfxOn) return;
    this.noise(0.5, 0.5, 1400);
    this.tone(160, 0.5, "sawtooth", 0.3, 0, 40);
    this.tone(90, 0.6, "sine", 0.35, 0.02, 30);
  }
  gameOver() {
    if (!this.sfxOn) return;
    const seq = [392, 330, 262, 196];
    seq.forEach((f, i) => this.tone(f, 0.32, "triangle", 0.2, 0.15 * i));
  }
  newHigh() {
    if (!this.sfxOn) return;
    const seq = [523, 659, 784, 1047];
    seq.forEach((f, i) => this.tone(f, 0.25, "square", 0.12, 0.1 * i));
  }
  gem() {
    if (!this.sfxOn) return;
    const seq = [784, 988, 1319, 1568];
    seq.forEach((f, i) => this.tone(f, 0.16, "triangle", 0.16, 0.045 * i));
    this.tone(2093, 0.25, "sine", 0.08, 0.16);
  }
  milestone() {
    if (!this.sfxOn) return;
    const seq = [392, 523, 659, 784, 1047];
    seq.forEach((f, i) => this.tone(f, 0.22, "square", 0.1, 0.07 * i));
    this.noise(0.3, 0.08, 4000, 0.1);
  }
  land() {
    if (!this.sfxOn) return;
    this.noise(0.09, 0.12, 500);
  }
  footstep(alt: boolean) {
    if (!this.sfxOn) return;
    this.noise(0.05, 0.05, alt ? 420 : 360);
  }
  whoosh() {
    if (!this.sfxOn) return;
    this.noise(0.16, 0.1, 2400);
    this.tone(900, 0.14, "sine", 0.05, 0, 300);
  }
  pauseBlip() {
    if (!this.sfxOn) return;
    this.tone(520, 0.09, "square", 0.1);
    this.tone(392, 0.12, "square", 0.09, 0.07);
  }

  /* ------- music: Tizita-pentatonic themes (soft menu / energetic run) ------- */
  startMusic(mode: MusicMode) {
    if (!this.ctx || !this.musicGain || this.musicTimer !== null) return;
    this.musicMode = mode;
    this.nextNoteTime = this.ctx.currentTime + 0.1;
    this.step = 0;
    const runMelody = [
      262, 0, 330, 294, 0, 392, 0, 440, 392, 0, 330, 0, 294, 262, 0, 0,
      262, 0, 294, 330, 0, 440, 0, 523, 440, 0, 392, 0, 330, 0, 294, 0,
    ];
    const runBass = [131, 0, 131, 0, 98, 0, 98, 0, 110, 0, 110, 0, 131, 0, 98, 0];
    const menuMelody = [
      262, 0, 0, 294, 0, 0, 330, 0, 392, 0, 0, 330, 0, 294, 0, 0,
      262, 0, 0, 220, 0, 0, 196, 0, 220, 0, 0, 262, 0, 0, 0, 0,
    ];
    const menuBass = [131, 0, 0, 0, 0, 0, 98, 0, 0, 0, 0, 0, 110, 0, 0, 0];
    const melody = mode === "run" ? runMelody : menuMelody;
    const bass = mode === "run" ? runBass : menuBass;
    const stepDur = mode === "run" ? 0.21 : 0.34;
    const tick = () => {
      if (!this.ctx || !this.musicGain) return;
      while (this.nextNoteTime < this.ctx.currentTime + 0.15) {
        const s = this.step % melody.length;
        const m = melody[s];
        if (m && this.musicOn) {
          this.pluck(m, this.nextNoteTime, mode === "run" ? 0.17 : 0.13);
          if (mode === "run" && s % 4 === 0) this.pluck(m / 2, this.nextNoteTime, 0.06);
        }
        const b = bass[s % bass.length];
        if (b && this.musicOn) {
          this.tone(b, stepDur * 1.8, "sine", mode === "run" ? 0.22 : 0.16, this.nextNoteTime - this.ctx.currentTime, undefined, this.musicGain);
        }
        this.nextNoteTime += stepDur;
        this.step++;
      }
    };
    this.musicTimer = window.setInterval(tick, 60);
  }

  private pluck(freq: number, when: number, vol: number) {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "triangle";
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(vol, when + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, when + 0.5);
    osc.connect(g);
    g.connect(this.musicGain);
    osc.start(when);
    osc.stop(when + 0.6);
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  dispose() {
    this.stopMusic();
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}
